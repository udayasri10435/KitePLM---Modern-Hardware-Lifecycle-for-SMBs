import React, { useState } from 'react';
import { BOMItem, PartCategory, SourcingType, LifecycleStage, ProductAssembly } from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { Layers, X } from 'lucide-react';

interface NewBOMItemModalProps {
  product: ProductAssembly;
  parentItem?: BOMItem;
  onClose: () => void;
  onAdd: (newItem: BOMItem, targetParentId: string | null) => void;
}

export const NewBOMItemModal: React.FC<NewBOMItemModalProps> = ({
  product,
  parentItem,
  onClose,
  onAdd
}) => {
  const [partNumber, setPartNumber] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<PartCategory>('Mechanical');
  const [quantity, setQuantity] = useState('1');
  const [unitOfMeasure, setUnitOfMeasure] = useState<BOMItem['unitOfMeasure']>('ea');
  const [unitCost, setUnitCost] = useState('12.50');
  const [leadTime, setLeadTime] = useState('4');
  const [sourcing, setSourcing] = useState<SourcingType>('Multi Source');
  const [primaryMpn, setPrimaryMpn] = useState('');
  const [primarySupplier, setPrimarySupplier] = useState('');
  const [selectedParentId, setSelectedParentId] = useState<string>(parentItem?.id || product.bom[0]?.id || '');

  const flatItems = flattenBOM(product.bom);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partNumber.trim() || !name.trim()) return;

    const parent = flatItems.find((p) => p.id === selectedParentId);
    const newLevel = parent ? parent.level + 1 : 1;

    const newItem: BOMItem = {
      id: `BOM-${Date.now()}`,
      partNumber: partNumber.toUpperCase(),
      name,
      revision: 'A',
      description,
      category,
      quantity: parseFloat(quantity) || 1,
      unitOfMeasure,
      unitCost: parseFloat(unitCost) || 0,
      leadTimeWeeks: parseInt(leadTime) || 4,
      lifecycle: 'EVT',
      sourcing,
      primaryMpn: primaryMpn || `${partNumber}-MPN`,
      primarySupplier: primarySupplier || 'Apex Precision CNC',
      compliance: 'RoHS & REACH Compliant',
      amlList: [
        {
          vendorId: `SUP-${Date.now()}`,
          vendorName: primarySupplier || 'Apex Precision CNC',
          mpn: primaryMpn || `${partNumber}-MPN`,
          isPreferred: true,
          unitCost: parseFloat(unitCost) || 0,
          leadTimeWeeks: parseInt(leadTime) || 4,
          moq: 100,
          packaging: 'Standard Bag',
          compliance: 'RoHS & REACH Compliant'
        }
      ],
      parentId: selectedParentId || null,
      level: newLevel,
      children: []
    };

    onAdd(newItem, selectedParentId || null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden text-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 font-display text-sm">
              Add Component to Bill of Materials
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Parent Subassembly</label>
            <select
              value={selectedParentId}
              onChange={(e) => setSelectedParentId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
            >
              {flatItems.map((p) => (
                <option key={p.id} value={p.id}>
                  {'· '.repeat(p.level)} {p.partNumber} ({p.name})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Part Number</label>
              <input
                type="text"
                required
                value={partNumber}
                onChange={(e) => setPartNumber(e.target.value)}
                placeholder="e.g. MEC-1150 or ELE-2340"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="Mechanical">Mechanical</option>
                <option value="Electrical">Electrical</option>
                <option value="PCBA">PCBA</option>
                <option value="Electromechanical">Electromechanical</option>
                <option value="Optical">Optical</option>
                <option value="Fasteners">Fasteners</option>
                <option value="Packaging">Packaging</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Item Title / Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Anodized Motor Mount Clamp"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Technical Description</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Material, tolerance, specs..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Quantity Per</label>
              <input
                type="number"
                step="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Unit of Measure</label>
              <select
                value={unitOfMeasure}
                onChange={(e) => setUnitOfMeasure(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              >
                <option value="ea">ea (each)</option>
                <option value="set">set</option>
                <option value="mm">mm</option>
                <option value="m">m</option>
                <option value="g">g</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Unit Cost ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={unitCost}
                onChange={(e) => setUnitCost(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Manufacturer Part # (MPN)</label>
              <input
                type="text"
                value={primaryMpn}
                onChange={(e) => setPrimaryMpn(e.target.value)}
                placeholder="e.g. AL-CLAMP-M3"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Lead Time (Weeks)</label>
              <input
                type="number"
                value={leadTime}
                onChange={(e) => setLeadTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
            >
              Add to BOM Tree
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
