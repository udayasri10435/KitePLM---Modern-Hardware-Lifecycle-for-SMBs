import React, { useState, useMemo } from 'react';
import { BOMItem, ProductAssembly } from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { Search, Database, ExternalLink, Plus, Filter, AlertTriangle, FileText } from 'lucide-react';

interface ItemMasterViewProps {
  products: ProductAssembly[];
  onSelectItem: (item: BOMItem) => void;
  onOpenWhereUsed: (item: BOMItem) => void;
  onInitiateECO: (item: BOMItem) => void;
  onOpenNewItemModal: () => void;
}

export const ItemMasterView: React.FC<ItemMasterViewProps> = ({
  products,
  onSelectItem,
  onOpenWhereUsed,
  onInitiateECO,
  onOpenNewItemModal
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Consolidate unique parts across all products by partNumber
  const uniqueItems = useMemo(() => {
    const map = new Map<string, { item: BOMItem; usages: number }>();

    products.forEach((prod) => {
      const flat = flattenBOM(prod.bom);
      flat.forEach((item) => {
        if (!map.has(item.partNumber)) {
          map.set(item.partNumber, { item, usages: 1 });
        } else {
          map.get(item.partNumber)!.usages += 1;
        }
      });
    });

    return Array.from(map.values());
  }, [products]);

  const filtered = uniqueItems.filter(({ item }) => {
    if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      item.partNumber.toLowerCase().includes(q) ||
      item.name.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.primaryMpn.toLowerCase().includes(q) ||
      item.primarySupplier.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Engineering Master Records
            </span>
            <span className="text-xs text-slate-500">·</span>
            <span className="text-xs text-slate-600 font-medium">Single Source of Truth</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 font-display">
            Company-Wide Item Master Catalog
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Standardized component registry across all assemblies, revisions, and contract manufacturing lines.
          </p>
        </div>

        <button
          onClick={onOpenNewItemModal}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Register New Item</span>
        </button>
      </div>

      {/* Filter toolbar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search all parts, MPNs, manufacturers..."
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-slate-500 font-medium flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            Category:
          </span>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden"
          >
            <option value="All">All Categories ({uniqueItems.length})</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Electrical">Electrical</option>
            <option value="PCBA">PCBA</option>
            <option value="Electromechanical">Electromechanical</option>
            <option value="Optical">Optical</option>
            <option value="Fasteners">Fasteners</option>
          </select>
        </div>
      </div>

      {/* Master Items Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase">
                <th className="py-2.5 px-3">Part Number</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Lifecycle</th>
                <th className="py-2.5 px-3 text-right">Unit Cost ($)</th>
                <th className="py-2.5 px-3 text-right">Lead Time</th>
                <th className="py-2.5 px-3">Sourcing</th>
                <th className="py-2.5 px-3">Where Used</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(({ item, usages }) => (
                <tr
                  key={item.partNumber}
                  onClick={() => onSelectItem(item)}
                  className="hover:bg-slate-50 cursor-pointer group transition-colors"
                >
                  <td className="py-3 px-3 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-slate-900 group-hover:text-indigo-600">
                        {item.partNumber}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1 py-0.5 rounded">
                        v{item.revision}
                      </span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                      MPN: {item.primaryMpn || 'N/A'}
                    </div>
                  </td>

                  <td className="py-3 px-3 max-w-xs">
                    <div className="font-medium text-slate-900 truncate">{item.name}</div>
                    <div className="text-[11px] text-slate-500 truncate">{item.description}</div>
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                    {item.category}
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap">
                    <span className="text-indigo-700 font-medium bg-indigo-50 px-2 py-0.5 rounded text-[11px]">
                      {item.lifecycle}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-800 font-medium">
                    ${item.unitCost.toFixed(2)}
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-700">
                    {item.leadTimeWeeks} wks
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap">
                    <span className={`text-[11px] font-medium ${
                      item.sourcing === 'Single Source' ? 'text-amber-700' : 'text-slate-600'
                    }`}>
                      {item.sourcing}
                    </span>
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onOpenWhereUsed(item)}
                      className="px-2 py-1 text-[11px] font-medium text-indigo-600 bg-indigo-50 border border-indigo-200/80 rounded hover:bg-indigo-100 flex items-center gap-1"
                    >
                      <span>{usages} assemblies</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </td>

                  <td className="py-3 px-3 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <button
                      onClick={() => onInitiateECO(item)}
                      className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded transition-colors"
                      title="Initiate Change Order"
                    >
                      <FileText className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
