import React, { useState, useMemo } from 'react';
import { ProductAssembly, BOMItem, PartCategory, SourcingType, LifecycleStage } from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { 
  ChevronRight, 
  ChevronDown, 
  Search, 
  Download, 
  Plus, 
  Layers, 
  DollarSign, 
  Clock, 
  Scale, 
  AlertTriangle, 
  ExternalLink,
  Filter,
  CheckCircle2,
  FileSpreadsheet,
  FileText
} from 'lucide-react';

interface BOMViewProps {
  product: ProductAssembly;
  onSelectItem: (item: BOMItem) => void;
  onOpenWhereUsed: (item: BOMItem) => void;
  onOpenAddModal: (parentItem?: BOMItem) => void;
  onInitiateECO: (item: BOMItem) => void;
  onDeleteBOMItem: (itemId: string) => void;
}

export const BOMView: React.FC<BOMViewProps> = ({
  product,
  onSelectItem,
  onOpenWhereUsed,
  onOpenAddModal,
  onInitiateECO,
  onDeleteBOMItem
}) => {
  const [viewMode, setViewMode] = useState<'tree' | 'flat'>('tree');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [sourcingFilter, setSourcingFilter] = useState<string>('All');
  const [collapsedNodes, setCollapsedNodes] = useState<Record<string, boolean>>({});

  const toggleNode = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCollapsedNodes((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const expandAll = () => setCollapsedNodes({});
  const collapseAll = () => {
    const allIds: Record<string, boolean> = {};
    const flat = flattenBOM(product.bom);
    flat.forEach((item) => {
      if (item.children && item.children.length > 0) {
        allIds[item.id] = true;
      }
    });
    setCollapsedNodes(allIds);
  };

  // Metrics calculation
  const flatItems = useMemo(() => flattenBOM(product.bom), [product.bom]);
  
  const totalCost = useMemo(() => {
    // If top item has rolled-up cost, or calculate from leaf items
    const top = product.bom[0];
    return top ? top.unitCost : flatItems.reduce((acc, i) => acc + (i.unitCost * i.quantity), 0);
  }, [product.bom, flatItems]);

  const maxLeadTime = useMemo(() => {
    return Math.max(...flatItems.map((i) => i.leadTimeWeeks), 0);
  }, [flatItems]);

  const singleSourceCount = useMemo(() => {
    return flatItems.filter((i) => i.sourcing === 'Single Source' || i.sourcing === 'Sole Source').length;
  }, [flatItems]);

  const totalWeightGrams = useMemo(() => {
    const top = product.bom[0];
    return top?.weightGrams || flatItems.reduce((acc, i) => acc + ((i.weightGrams || 0) * i.quantity), 0);
  }, [product.bom, flatItems]);

  // CSV Export handler
  const exportCSV = () => {
    const headers = ['Level', 'Part Number', 'Revision', 'Description', 'Category', 'Quantity', 'UoM', 'Unit Cost ($)', 'Ext Cost ($)', 'Lead Time (wks)', 'Sourcing', 'Primary MPN', 'Supplier'];
    const rows = flatItems.map((item) => [
      item.level,
      `"${item.partNumber}"`,
      `"${item.revision}"`,
      `"${item.name} - ${item.description.replace(/"/g, '""')}"`,
      `"${item.category}"`,
      item.quantity,
      item.unitOfMeasure,
      item.unitCost.toFixed(2),
      (item.unitCost * item.quantity).toFixed(2),
      item.leadTimeWeeks,
      `"${item.sourcing}"`,
      `"${item.primaryMpn}"`,
      `"${item.primarySupplier}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${product.sku}_BOM_Rev${product.currentRevision}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter items logic
  const matchesSearch = (item: BOMItem): boolean => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      item.partNumber.toLowerCase().includes(query) ||
      item.name.toLowerCase().includes(query) ||
      item.description.toLowerCase().includes(query) ||
      item.primaryMpn.toLowerCase().includes(query) ||
      item.primarySupplier.toLowerCase().includes(query)
    );
  };

  const matchesFilters = (item: BOMItem): boolean => {
    if (categoryFilter !== 'All' && item.category !== categoryFilter) return false;
    if (sourcingFilter !== 'All' && item.sourcing !== sourcingFilter) return false;
    return true;
  };

  // Recursive tree rendering
  const renderTreeRows = (items: BOMItem[], currentLevel: number = 0): React.ReactNode => {
    return items.map((item) => {
      const isCollapsed = !!collapsedNodes[item.id];
      const hasChildren = item.children && item.children.length > 0;
      const isVisible = matchesSearch(item) && matchesFilters(item);

      // Check if any child matches search even if parent doesn't
      const childMatch = hasChildren && flattenBOM(item.children || []).some((c) => matchesSearch(c) && matchesFilters(c));
      if (!isVisible && !childMatch) return null;

      return (
        <React.Fragment key={item.id}>
          <tr 
            onClick={() => onSelectItem(item)}
            className={`border-b border-slate-100 hover:bg-slate-50/80 cursor-pointer group text-xs transition-colors ${
              item.level === 0 ? 'bg-slate-50/90 font-semibold' : ''
            }`}
          >
            {/* Level & Part Number column with hierarchical tree indent */}
            <td className="py-2.5 px-3 whitespace-nowrap">
              <div className="flex items-center" style={{ paddingLeft: `${item.level * 20}px` }}>
                {hasChildren ? (
                  <button
                    onClick={(e) => toggleNode(item.id, e)}
                    className="p-1 hover:bg-slate-200 rounded text-slate-500 mr-1.5 focus:outline-hidden"
                  >
                    {isCollapsed ? (
                      <ChevronRight className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </button>
                ) : (
                  <span className="w-5 text-slate-300 inline-block text-center mr-1">
                    {item.level > 0 ? '└' : ''}
                  </span>
                )}
                <span className="font-mono font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {item.partNumber}
                </span>
                <span className="ml-1.5 px-1 py-0.2 text-[10px] font-mono font-medium text-slate-500 bg-slate-100 rounded">
                  v{item.revision}
                </span>
              </div>
            </td>

            {/* Description & MPN */}
            <td className="py-2.5 px-3 max-w-[280px]">
              <div className="font-medium text-slate-900 truncate">{item.name}</div>
              <div className="text-[11px] text-slate-500 truncate">{item.description}</div>
            </td>

            {/* Category */}
            <td className="py-2.5 px-3 whitespace-nowrap">
              <span className="inline-block text-[11px] text-slate-600 font-medium">
                {item.category}
              </span>
            </td>

            {/* Qty & UoM */}
            <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
              <span className="font-semibold text-slate-800">{item.quantity}</span>{' '}
              <span className="text-[11px] text-slate-500">{item.unitOfMeasure}</span>
            </td>

            {/* Unit Cost ($) */}
            <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-700">
              ${item.unitCost.toFixed(2)}
            </td>

            {/* Rolled-up Extended Cost */}
            <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap font-medium text-slate-900">
              ${(item.unitCost * item.quantity).toFixed(2)}
            </td>

            {/* Lead Time (wks) */}
            <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
              <span className={`inline-flex items-center gap-1 ${
                item.leadTimeWeeks >= 12 ? 'text-rose-600 font-bold' : item.leadTimeWeeks >= 6 ? 'text-amber-600' : 'text-slate-600'
              }`}>
                {item.leadTimeWeeks >= 12 && <AlertTriangle className="w-3 h-3 text-rose-500" />}
                {item.leadTimeWeeks} w
              </span>
            </td>

            {/* Sourcing Risk */}
            <td className="py-2.5 px-3 whitespace-nowrap">
              <span className={`text-[11px] font-medium ${
                item.sourcing === 'Single Source' || item.sourcing === 'Sole Source'
                  ? 'text-amber-700 font-semibold'
                  : 'text-slate-600'
              }`}>
                {item.sourcing}
              </span>
            </td>

            {/* Primary AML / MPN */}
            <td className="py-2.5 px-3 whitespace-nowrap max-w-[160px] truncate">
              <div className="text-slate-900 font-mono text-[11px] truncate">{item.primaryMpn || 'N/A'}</div>
              <div className="text-slate-500 text-[10px] truncate">{item.primarySupplier || 'In-House'}</div>
            </td>

            {/* Actions */}
            <td className="py-2.5 px-3 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-end gap-1 opacity-80 group-hover:opacity-100">
                <button
                  onClick={() => onOpenWhereUsed(item)}
                  title="Where-Used Dependency Search"
                  className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onOpenAddModal(item)}
                  title="Add Sub-component under this assembly"
                  className="p-1 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onInitiateECO(item)}
                  title="Initiate ECO Redline"
                  className="p-1 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                </button>
              </div>
            </td>
          </tr>

          {/* Render children if not collapsed */}
          {!isCollapsed && hasChildren && renderTreeRows(item.children || [], currentLevel + 1)}
        </React.Fragment>
      );
    });
  };

  return (
    <div className="space-y-6">
      {/* Product Information Hero Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                {product.sku}
              </span>
              <span className="text-xs font-medium text-slate-600">
                Rev {product.currentRevision}
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                {product.lifecycle} Stage
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-slate-500 font-mono">Code: {product.codeName}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
              {product.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-3xl">
              {product.description}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={exportCSV}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => onOpenAddModal()}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Part / Subassembly</span>
            </button>
          </div>
        </div>

        {/* High Density Metric Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5 pt-5 border-t border-slate-100">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-0.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Total BOM Unit Cost</span>
            </div>
            <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
              ${totalCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-0.5">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span>Unique Line Items</span>
            </div>
            <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
              {flatItems.length} parts
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-0.5">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>Critical Path Lead Time</span>
            </div>
            <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
              {maxLeadTime} weeks
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-0.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>Single-Source Risks</span>
            </div>
            <div className="text-lg font-bold font-mono text-amber-700 tabular-nums">
              {singleSourceCount} items
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-0.5">
              <Scale className="w-3.5 h-3.5 text-slate-600" />
              <span>Estimated Weight</span>
            </div>
            <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
              {(totalWeightGrams / 1000).toFixed(2)} kg
            </div>
          </div>
        </div>
      </div>

      {/* Table Controls & Filter Toolbar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search part #, description, MPN, vendor..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-slate-900 placeholder:text-slate-400"
            />
          </div>

          {/* View Toggle & Tree Controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200/80 text-xs">
              <button
                onClick={() => setViewMode('tree')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  viewMode === 'tree' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Multi-Level Tree
              </button>
              <button
                onClick={() => setViewMode('flat')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  viewMode === 'flat' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Flat Purchasing
              </button>
            </div>

            {viewMode === 'tree' && (
              <div className="hidden sm:flex items-center gap-1 text-xs">
                <button
                  onClick={expandAll}
                  className="px-2.5 py-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded border border-slate-200"
                >
                  Expand All
                </button>
                <button
                  onClick={collapseAll}
                  className="px-2.5 py-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded border border-slate-200"
                >
                  Collapse
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Filter Badges & Selectors */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500 flex items-center gap-1 font-medium">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            Filters:
          </span>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded text-slate-700 text-xs focus:outline-hidden"
          >
            <option value="All">All Categories</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Electrical">Electrical</option>
            <option value="PCBA">PCBA</option>
            <option value="Electromechanical">Electromechanical</option>
            <option value="Optical">Optical</option>
            <option value="Fasteners">Fasteners</option>
          </select>

          <select
            value={sourcingFilter}
            onChange={(e) => setSourcingFilter(e.target.value)}
            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded text-slate-700 text-xs focus:outline-hidden"
          >
            <option value="All">All Sourcing Types</option>
            <option value="Single Source">Single Source (High Risk)</option>
            <option value="Multi Source">Multi Source</option>
            <option value="Custom Tooling">Custom Tooling</option>
            <option value="Sole Source">Sole Source</option>
          </select>

          {(categoryFilter !== 'All' || sourcingFilter !== 'All' || searchQuery) && (
            <button
              onClick={() => {
                setCategoryFilter('All');
                setSourcingFilter('All');
                setSearchQuery('');
              }}
              className="text-xs text-indigo-600 hover:text-indigo-800 ml-auto font-medium"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Main High-Density BOM Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-2.5 px-3 min-w-[220px]">Level & Part Number</th>
                <th className="py-2.5 px-3 min-w-[240px]">Item Description</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Qty Per</th>
                <th className="py-2.5 px-3 text-right">Unit ($)</th>
                <th className="py-2.5 px-3 text-right">Ext Cost ($)</th>
                <th className="py-2.5 px-3 text-right">Lead (wks)</th>
                <th className="py-2.5 px-3">Sourcing</th>
                <th className="py-2.5 px-3">Primary MPN / AML</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {viewMode === 'tree' ? (
                renderTreeRows(product.bom)
              ) : (
                flatItems
                  .filter((item) => matchesSearch(item) && matchesFilters(item))
                  .map((item) => (
                    <tr
                      key={item.id}
                      onClick={() => onSelectItem(item)}
                      className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer group text-xs transition-colors"
                    >
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-1 py-0.5 rounded">
                            L{item.level}
                          </span>
                          <span className="font-mono font-bold text-slate-900 group-hover:text-indigo-600">
                            {item.partNumber}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">
                            v{item.revision}
                          </span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 max-w-[280px]">
                        <div className="font-medium text-slate-900 truncate">{item.name}</div>
                        <div className="text-[11px] text-slate-500 truncate">{item.description}</div>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap text-slate-600">
                        {item.category}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap font-semibold text-slate-800">
                        {item.quantity} {item.unitOfMeasure}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-700">
                        ${item.unitCost.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap font-medium text-slate-900">
                        ${(item.unitCost * item.quantity).toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 ${
                          item.leadTimeWeeks >= 12 ? 'text-rose-600 font-bold' : item.leadTimeWeeks >= 6 ? 'text-amber-600' : 'text-slate-600'
                        }`}>
                          {item.leadTimeWeeks >= 12 && <AlertTriangle className="w-3 h-3 text-rose-500" />}
                          {item.leadTimeWeeks} w
                        </span>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className={`text-[11px] font-medium ${
                          item.sourcing === 'Single Source' ? 'text-amber-700 font-semibold' : 'text-slate-600'
                        }`}>
                          {item.sourcing}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap max-w-[160px] truncate">
                        <div className="text-slate-900 font-mono text-[11px] truncate">{item.primaryMpn || 'N/A'}</div>
                        <div className="text-slate-500 text-[10px] truncate">{item.primarySupplier}</div>
                      </td>
                      <td className="py-2.5 px-3 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onOpenWhereUsed(item)}
                            className="p-1 text-slate-400 hover:text-indigo-600 rounded"
                            title="Where-Used"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onInitiateECO(item)}
                            className="p-1 text-slate-400 hover:text-amber-600 rounded"
                            title="Initiate ECO"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
