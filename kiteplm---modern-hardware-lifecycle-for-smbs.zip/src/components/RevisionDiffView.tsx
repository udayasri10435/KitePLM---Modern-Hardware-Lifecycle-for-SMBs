import React, { useState, useMemo } from 'react';
import { ProductAssembly, BOMRevisionSnapshot, BOMItem } from '../types/plm';
import { GitCompare, Plus, Minus, RefreshCw, FileText, ArrowRight, CheckCircle2 } from 'lucide-react';

interface RevisionDiffViewProps {
  product: ProductAssembly;
  revisions: BOMRevisionSnapshot[];
  onOpenECO: (ecoNumber: string) => void;
}

type DiffStatus = 'ADDED' | 'REMOVED' | 'MODIFIED' | 'UNCHANGED';

interface DiffRow {
  partNumber: string;
  name: string;
  category: string;
  status: DiffStatus;
  baseItem?: BOMItem;
  compareItem?: BOMItem;
  changes: {
    field: string;
    from: string | number;
    to: string | number;
  }[];
}

export const RevisionDiffView: React.FC<RevisionDiffViewProps> = ({
  product,
  revisions,
  onOpenECO
}) => {
  // Filter revisions for this product
  const productRevisions = useMemo(() => {
    return revisions.filter((r) => r.productId === product.id);
  }, [revisions, product.id]);

  const [baseRevId, setBaseRevId] = useState<string>(
    productRevisions[0]?.id || ''
  );
  const [compareRevId, setCompareRevId] = useState<string>(
    productRevisions[1]?.id || productRevisions[0]?.id || ''
  );
  const [filterType, setFilterType] = useState<'ALL' | 'DIFF_ONLY' | 'ADDED' | 'MODIFIED' | 'REMOVED'>('DIFF_ONLY');

  const baseSnapshot = useMemo(() => {
    return productRevisions.find((r) => r.id === baseRevId);
  }, [productRevisions, baseRevId]);

  const compareSnapshot = useMemo(() => {
    return productRevisions.find((r) => r.id === compareRevId);
  }, [productRevisions, compareRevId]);

  // Compute diffs between base and compare
  const diffRows = useMemo((): DiffRow[] => {
    if (!baseSnapshot || !compareSnapshot) return [];

    const baseMap = new Map<string, BOMItem>();
    baseSnapshot.items.forEach((item) => baseMap.set(item.partNumber, item));

    const compareMap = new Map<string, BOMItem>();
    compareSnapshot.items.forEach((item) => compareMap.set(item.partNumber, item));

    const allPartNumbers = Array.from(
      new Set([...baseMap.keys(), ...compareMap.keys()])
    );

    const rows: DiffRow[] = [];

    allPartNumbers.forEach((pn) => {
      const baseItem = baseMap.get(pn);
      const compareItem = compareMap.get(pn);

      if (!baseItem && compareItem) {
        // ADDED in compare
        rows.push({
          partNumber: pn,
          name: compareItem.name,
          category: compareItem.category,
          status: 'ADDED',
          compareItem,
          changes: []
        });
      } else if (baseItem && !compareItem) {
        // REMOVED in compare
        rows.push({
          partNumber: pn,
          name: baseItem.name,
          category: baseItem.category,
          status: 'REMOVED',
          baseItem,
          changes: []
        });
      } else if (baseItem && compareItem) {
        // Exists in both; inspect field changes
        const changes: { field: string; from: string | number; to: string | number }[] = [];

        if (baseItem.revision !== compareItem.revision) {
          changes.push({ field: 'Rev', from: baseItem.revision, to: compareItem.revision });
        }
        if (baseItem.quantity !== compareItem.quantity) {
          changes.push({ field: 'Qty', from: baseItem.quantity, to: compareItem.quantity });
        }
        if (baseItem.unitCost !== compareItem.unitCost) {
          changes.push({ field: 'Unit Cost', from: `$${baseItem.unitCost.toFixed(2)}`, to: `$${compareItem.unitCost.toFixed(2)}` });
        }
        if (baseItem.primaryMpn !== compareItem.primaryMpn) {
          changes.push({ field: 'MPN', from: baseItem.primaryMpn, to: compareItem.primaryMpn });
        }
        if (baseItem.leadTimeWeeks !== compareItem.leadTimeWeeks) {
          changes.push({ field: 'Lead Time', from: `${baseItem.leadTimeWeeks}w`, to: `${compareItem.leadTimeWeeks}w` });
        }

        if (changes.length > 0) {
          rows.push({
            partNumber: pn,
            name: compareItem.name,
            category: compareItem.category,
            status: 'MODIFIED',
            baseItem,
            compareItem,
            changes
          });
        } else {
          rows.push({
            partNumber: pn,
            name: compareItem.name,
            category: compareItem.category,
            status: 'UNCHANGED',
            baseItem,
            compareItem,
            changes: []
          });
        }
      }
    });

    return rows;
  }, [baseSnapshot, compareSnapshot]);

  // Delta calculations
  const addedCount = diffRows.filter((r) => r.status === 'ADDED').length;
  const removedCount = diffRows.filter((r) => r.status === 'REMOVED').length;
  const modifiedCount = diffRows.filter((r) => r.status === 'MODIFIED').length;
  const unchangedCount = diffRows.filter((r) => r.status === 'UNCHANGED').length;

  const costDelta = (compareSnapshot?.totalCost || 0) - (baseSnapshot?.totalCost || 0);
  const weightDelta = (compareSnapshot?.totalWeightGrams || 0) - (baseSnapshot?.totalWeightGrams || 0);

  const filteredRows = diffRows.filter((row) => {
    if (filterType === 'DIFF_ONLY') return row.status !== 'UNCHANGED';
    if (filterType === 'ADDED') return row.status === 'ADDED';
    if (filterType === 'MODIFIED') return row.status === 'MODIFIED';
    if (filterType === 'REMOVED') return row.status === 'REMOVED';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header and Selectors */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                BOM Time Machine
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-600 font-medium">{product.sku} ({product.name})</span>
            </div>
            <h1 className="text-xl font-bold text-slate-900 font-display">
              Visual BOM Revision Comparison
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Side-by-side component diffing tracking added, modified, and obsoleted parts across releases.
            </p>
          </div>

          {/* Revision Dropdowns */}
          <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-xl border border-slate-200 text-xs">
            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-500 mb-1">
                Base Baseline
              </label>
              <select
                value={baseRevId}
                onChange={(e) => setBaseRevId(e.target.value)}
                className="bg-white border border-slate-300 rounded-md px-2.5 py-1.5 font-medium text-slate-900 focus:outline-hidden"
              >
                {productRevisions.map((rev) => (
                  <option key={rev.id} value={rev.id}>
                    Rev {rev.revision} ({rev.releaseDate})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center pt-4 text-slate-400">
              <ArrowRight className="w-4 h-4" />
            </div>

            <div>
              <label className="block text-[10px] font-semibold uppercase text-slate-500 mb-1">
                Target Revision
              </label>
              <select
                value={compareRevId}
                onChange={(e) => setCompareRevId(e.target.value)}
                className="bg-white border border-slate-300 rounded-md px-2.5 py-1.5 font-medium text-slate-900 focus:outline-hidden"
              >
                {productRevisions.map((rev) => (
                  <option key={rev.id} value={rev.id}>
                    Rev {rev.revision} ({rev.releaseDate})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Change Impact Summary Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-5">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Net Cost Impact</span>
            <div className={`text-base font-bold font-mono tabular-nums ${costDelta < 0 ? 'text-emerald-600' : costDelta > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {costDelta < 0 ? `-$${Math.abs(costDelta).toFixed(2)}` : costDelta > 0 ? `+$${costDelta.toFixed(2)}` : '$0.00'}
              <span className="text-xs font-normal text-slate-500 ml-1">
                ({baseSnapshot?.totalCost ? ((costDelta / baseSnapshot.totalCost) * 100).toFixed(1) : 0}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">Net Weight Delta</span>
            <div className={`text-base font-bold font-mono tabular-nums ${weightDelta < 0 ? 'text-emerald-600' : weightDelta > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {weightDelta > 0 ? `+${weightDelta}g` : `${weightDelta}g`}
            </div>
          </div>

          <div className="p-3 bg-emerald-50/60 rounded-lg border border-emerald-200">
            <div className="flex items-center gap-1 text-xs text-emerald-800 mb-1">
              <Plus className="w-3.5 h-3.5" />
              <span>Added Items</span>
            </div>
            <div className="text-base font-bold font-mono text-emerald-700 tabular-nums">
              +{addedCount} parts
            </div>
          </div>

          <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200">
            <div className="flex items-center gap-1 text-xs text-amber-800 mb-1">
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Modified Items</span>
            </div>
            <div className="text-base font-bold font-mono text-amber-700 tabular-nums">
              {modifiedCount} items
            </div>
          </div>

          <div className="p-3 bg-rose-50/60 rounded-lg border border-rose-200 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-1 text-xs text-rose-800 mb-1">
              <Minus className="w-3.5 h-3.5" />
              <span>Removed / Obsoleted</span>
            </div>
            <div className="text-base font-bold font-mono text-rose-700 tabular-nums">
              -{removedCount} items
            </div>
          </div>
        </div>

        {/* Governing ECO Notice if present */}
        {compareSnapshot?.ecoReference && (
          <div className="mt-4 p-3 bg-indigo-50/60 border border-indigo-100 rounded-lg flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span className="text-indigo-900 font-medium">
                Governed by Change Order: <strong className="font-mono">{compareSnapshot.ecoReference}</strong>
              </span>
              <span className="text-slate-500 hidden sm:inline">· {compareSnapshot.description}</span>
            </div>
            <button
              onClick={() => onOpenECO(compareSnapshot.ecoReference!)}
              className="px-2.5 py-1 font-semibold text-indigo-700 hover:text-indigo-900 bg-white border border-indigo-200 rounded shadow-2xs hover:bg-indigo-50"
            >
              Inspect ECO
            </button>
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-fit text-xs border border-slate-200">
        <button
          onClick={() => setFilterType('DIFF_ONLY')}
          className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
            filterType === 'DIFF_ONLY' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All Diffs ({addedCount + modifiedCount + removedCount})
        </button>
        <button
          onClick={() => setFilterType('ADDED')}
          className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
            filterType === 'ADDED' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Added ({addedCount})
        </button>
        <button
          onClick={() => setFilterType('MODIFIED')}
          className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
            filterType === 'MODIFIED' ? 'bg-white text-amber-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Modified ({modifiedCount})
        </button>
        <button
          onClick={() => setFilterType('REMOVED')}
          className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
            filterType === 'REMOVED' ? 'bg-white text-rose-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Removed ({removedCount})
        </button>
        <button
          onClick={() => setFilterType('ALL')}
          className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
            filterType === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Show All Including Unchanged ({diffRows.length})
        </button>
      </div>

      {/* Diff Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase tracking-wider">
                <th className="py-2.5 px-3">Diff Status</th>
                <th className="py-2.5 px-3">Part Number</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Changes & Redlines (Base → Compare)</th>
                <th className="py-2.5 px-3 text-right">Target Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredRows.map((row) => (
                <tr
                  key={row.partNumber}
                  className={`hover:bg-slate-50/80 transition-colors ${
                    row.status === 'ADDED'
                      ? 'bg-emerald-50/30'
                      : row.status === 'REMOVED'
                      ? 'bg-rose-50/30 opacity-75'
                      : row.status === 'MODIFIED'
                      ? 'bg-amber-50/20'
                      : ''
                  }`}
                >
                  {/* Status Indicator */}
                  <td className="py-3 px-3 whitespace-nowrap">
                    {row.status === 'ADDED' && (
                      <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded text-[11px]">
                        <Plus className="w-3 h-3" />
                        ADDED
                      </span>
                    )}
                    {row.status === 'REMOVED' && (
                      <span className="inline-flex items-center gap-1 font-semibold text-rose-700 bg-rose-100/70 px-2 py-0.5 rounded text-[11px]">
                        <Minus className="w-3 h-3" />
                        REMOVED
                      </span>
                    )}
                    {row.status === 'MODIFIED' && (
                      <span className="inline-flex items-center gap-1 font-semibold text-amber-700 bg-amber-100/70 px-2 py-0.5 rounded text-[11px]">
                        <RefreshCw className="w-3 h-3" />
                        MODIFIED
                      </span>
                    )}
                    {row.status === 'UNCHANGED' && (
                      <span className="text-slate-400 text-[11px]">Unchanged</span>
                    )}
                  </td>

                  {/* Part Number */}
                  <td className="py-3 px-3 whitespace-nowrap font-mono font-bold text-slate-900">
                    <span className={row.status === 'REMOVED' ? 'line-through text-slate-400' : ''}>
                      {row.partNumber}
                    </span>
                  </td>

                  {/* Name */}
                  <td className="py-3 px-3">
                    <div className={`font-medium ${row.status === 'REMOVED' ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                      {row.name}
                    </div>
                  </td>

                  {/* Category */}
                  <td className="py-3 px-3 whitespace-nowrap text-slate-600">
                    {row.category}
                  </td>

                  {/* Changes & Redlines */}
                  <td className="py-3 px-3">
                    {row.status === 'ADDED' && row.compareItem && (
                      <span className="text-emerald-700 text-xs">
                        Introduced at Rev {row.compareItem.revision} · Qty: {row.compareItem.quantity} {row.compareItem.unitOfMeasure} · MPN: {row.compareItem.primaryMpn}
                      </span>
                    )}
                    {row.status === 'REMOVED' && row.baseItem && (
                      <span className="text-rose-700 text-xs line-through">
                        Obsoleted from Rev {row.baseItem.revision} · Was Qty: {row.baseItem.quantity} · MPN: {row.baseItem.primaryMpn}
                      </span>
                    )}
                    {row.status === 'MODIFIED' && (
                      <div className="flex flex-wrap gap-2">
                        {row.changes.map((c, i) => (
                          <div key={i} className="inline-flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/80 text-[11px]">
                            <span className="font-semibold text-amber-900">{c.field}:</span>
                            <span className="line-through text-slate-500 font-mono">{c.from}</span>
                            <span className="text-slate-400">→</span>
                            <span className="font-bold text-amber-800 font-mono">{c.to}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {row.status === 'UNCHANGED' && (
                      <span className="text-slate-400 text-xs">No configuration delta</span>
                    )}
                  </td>

                  {/* Cost */}
                  <td className="py-3 px-3 text-right whitespace-nowrap font-mono tabular-nums font-medium text-slate-800">
                    {row.compareItem ? `$${row.compareItem.unitCost.toFixed(2)}` : (
                      <span className="line-through text-slate-400">${row.baseItem?.unitCost.toFixed(2)}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
