import React from 'react';
import { PartCategory } from '../types/plm';

interface CADPreviewProps {
  partNumber: string;
  name: string;
  category: PartCategory;
  revision: string;
}

export const CADPreview: React.FC<CADPreviewProps> = ({
  partNumber,
  name,
  category,
  revision
}) => {
  return (
    <div className="relative w-full h-56 bg-slate-900 rounded-lg overflow-hidden border border-slate-800 flex flex-col justify-between p-4 font-mono select-none">
      {/* Background blueprint grid */}
      <div 
        className="absolute inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, #38bdf8 1px, transparent 1px),
            linear-gradient(to bottom, #38bdf8 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px'
        }}
      />

      {/* Header telemetry / title block */}
      <div className="relative z-10 flex items-center justify-between text-[11px] text-sky-400/80 border-b border-sky-950 pb-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="tracking-wider uppercase">3D CAD / 2D Drawing Spec</span>
        </div>
        <div className="text-slate-400">
          REV <span className="text-white font-semibold">{revision}</span> · SCALE 1:1
        </div>
      </div>

      {/* Center Technical Schematic Graphic based on category */}
      <div className="relative z-10 flex-1 flex items-center justify-center py-2">
        {category === 'Mechanical' && (
          <svg className="w-48 h-32 text-sky-400 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            {/* CNC Milling Contour */}
            <rect x="25" y="20" width="150" height="80" rx="8" strokeDasharray="none" className="stroke-sky-400" />
            <circle cx="50" cy="45" r="10" stroke="#38bdf8" strokeWidth="1.5" />
            <circle cx="150" cy="45" r="10" stroke="#38bdf8" strokeWidth="1.5" />
            <circle cx="100" cy="60" r="18" stroke="#38bdf8" strokeWidth="1.5" />
            {/* Centerlines */}
            <line x1="15" y1="60" x2="185" y2="60" stroke="#0ea5e9" strokeWidth="0.8" strokeDasharray="4 2" />
            <line x1="100" y1="10" x2="100" y2="110" stroke="#0ea5e9" strokeWidth="0.8" strokeDasharray="4 2" />
            {/* Dimension lines */}
            <line x1="25" y1="108" x2="175" y2="108" stroke="#38bdf8" strokeWidth="0.8" />
            <text x="100" y="117" textAnchor="middle" fill="#7dd3fc" fontSize="8" fontFamily="monospace">150.00 ± 0.05 mm</text>
          </svg>
        )}

        {(category === 'Electrical' || category === 'PCBA') && (
          <svg className="w-48 h-32 text-emerald-400 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            {/* PCBA substrate */}
            <rect x="30" y="15" width="140" height="90" rx="4" stroke="#10b981" strokeWidth="1.5" fill="#064e3b" fillOpacity="0.2" />
            {/* IC Package */}
            <rect x="75" y="35" width="50" height="50" rx="2" stroke="#34d399" strokeWidth="1.5" fill="#022c22" />
            <circle cx="83" cy="43" r="2" fill="#34d399" />
            {/* Traces */}
            <path d="M 45 35 L 75 35 M 45 45 L 75 45 M 45 55 L 75 55" stroke="#34d399" strokeWidth="1" />
            <path d="M 125 40 L 155 40 M 125 50 L 155 50 M 125 60 L 155 60" stroke="#34d399" strokeWidth="1" />
            <path d="M 90 85 L 90 98 M 100 85 L 100 98 M 110 85 L 110 98" stroke="#34d399" strokeWidth="1" />
            {/* Vias */}
            <circle cx="50" cy="80" r="3" stroke="#34d399" />
            <circle cx="62" cy="80" r="3" stroke="#34d399" />
            <circle cx="145" cy="80" r="3" stroke="#34d399" />
            <text x="100" y="63" textAnchor="middle" fill="#6ee7b7" fontSize="8" fontFamily="monospace">MCU / PCBA</text>
          </svg>
        )}

        {category === 'Electromechanical' && (
          <svg className="w-48 h-32 text-amber-400 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            {/* Brushless motor / Actuator concentric view */}
            <circle cx="100" cy="60" r="42" stroke="#fbbf24" strokeWidth="1.5" />
            <circle cx="100" cy="60" r="32" stroke="#f59e0b" strokeWidth="1.2" strokeDasharray="3 3" />
            <circle cx="100" cy="60" r="16" stroke="#fbbf24" strokeWidth="1.5" />
            <circle cx="100" cy="60" r="6" stroke="#fbbf24" strokeWidth="1.5" fill="#78350f" fillOpacity="0.5" />
            {/* Rotor stator poles */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
              <line 
                key={deg} 
                x1={100 + 20 * Math.cos((deg * Math.PI) / 180)} 
                y1={60 + 20 * Math.sin((deg * Math.PI) / 180)} 
                x2={100 + 30 * Math.cos((deg * Math.PI) / 180)} 
                y2={60 + 30 * Math.sin((deg * Math.PI) / 180)} 
                stroke="#fbbf24" 
                strokeWidth="1.2"
              />
            ))}
            <text x="100" y="115" textAnchor="middle" fill="#fde68a" fontSize="8" fontFamily="monospace">BLDC ROTOR Ø42.0</text>
          </svg>
        )}

        {category === 'Fasteners' && (
          <svg className="w-48 h-32 text-slate-300 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            {/* Torx / Button head screw profile */}
            <path d="M 60 40 Q 100 25 140 40 L 135 55 L 115 55 L 115 95 L 85 95 L 85 55 L 65 55 Z" stroke="#cbd5e1" strokeWidth="1.5" fill="#334155" fillOpacity="0.4" />
            {/* Threads */}
            <line x1="85" y1="65" x2="115" y2="60" stroke="#94a3b8" strokeWidth="1" />
            <line x1="85" y1="75" x2="115" y2="70" stroke="#94a3b8" strokeWidth="1" />
            <line x1="85" y1="85" x2="115" y2="80" stroke="#94a3b8" strokeWidth="1" />
            <text x="100" y="110" textAnchor="middle" fill="#cbd5e1" fontSize="8" fontFamily="monospace">M3x0.5 - 6g TORX</text>
          </svg>
        )}

        {category === 'Optical' && (
          <svg className="w-48 h-32 text-indigo-400 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            {/* Optical lens & sensor path */}
            <path d="M 60 25 Q 75 60 60 95 L 75 95 Q 90 60 75 25 Z" stroke="#818cf8" strokeWidth="1.5" fill="#312e81" fillOpacity="0.4" />
            <path d="M 90 30 Q 100 60 90 90 L 105 90 Q 115 60 105 30 Z" stroke="#818cf8" strokeWidth="1.5" fill="#312e81" fillOpacity="0.4" />
            <rect x="140" y="38" width="10" height="44" stroke="#a5b4fc" strokeWidth="1.5" fill="#4338ca" />
            {/* Laser beam cone */}
            <line x1="30" y1="60" x2="140" y2="60" stroke="#c7d2fe" strokeWidth="1" strokeDasharray="3 2" />
            <line x1="30" y1="40" x2="140" y2="55" stroke="#818cf8" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6" />
            <line x1="30" y1="80" x2="140" y2="65" stroke="#818cf8" strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6" />
            <text x="100" y="112" textAnchor="middle" fill="#c7d2fe" fontSize="8" fontFamily="monospace">OPTICAL FOCAL AXIS</text>
          </svg>
        )}

        {category !== 'Mechanical' && category !== 'Electrical' && category !== 'PCBA' && category !== 'Electromechanical' && category !== 'Fasteners' && category !== 'Optical' && (
          <svg className="w-48 h-32 text-slate-400 stroke-current fill-none stroke-[1.5]" viewBox="0 0 200 120">
            <rect x="50" y="30" width="100" height="60" rx="4" stroke="#94a3b8" strokeWidth="1.5" />
            <line x1="50" y1="30" x2="150" y2="90" stroke="#64748b" strokeWidth="1" strokeDasharray="4 4" />
            <line x1="150" y1="30" x2="50" y2="90" stroke="#64748b" strokeWidth="1" strokeDasharray="4 4" />
            <text x="100" y="64" textAnchor="middle" fill="#cbd5e1" fontSize="9" fontFamily="monospace">PART SPEC</text>
          </svg>
        )}
      </div>

      {/* Footer title block */}
      <div className="relative z-10 flex items-center justify-between text-[11px] border-t border-sky-950 pt-2 text-slate-400">
        <div className="truncate max-w-[200px]">
          <span className="text-white font-medium">{partNumber}</span> · {name}
        </div>
        <div className="text-[10px] text-sky-400/80 uppercase">
          ISO 2768-mK TOLERANCE
        </div>
      </div>
    </div>
  );
};
