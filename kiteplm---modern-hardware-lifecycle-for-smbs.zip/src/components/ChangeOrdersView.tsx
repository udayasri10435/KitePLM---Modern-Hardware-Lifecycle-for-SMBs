import React, { useState } from 'react';
import { 
  EngineeringChangeOrder, 
  ProductAssembly, 
  ECOStatus, 
  ECOPriority, 
  ECOAffectedItem, 
  Disposition,
  ECOSignoff,
  BOMItem
} from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { 
  FileText, 
  Plus, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldAlert, 
  DollarSign, 
  Calendar, 
  User, 
  X, 
  Check, 
  ExternalLink,
  ChevronRight,
  TrendingDown,
  Layers
} from 'lucide-react';

interface ChangeOrdersViewProps {
  ecos: EngineeringChangeOrder[];
  products: ProductAssembly[];
  selectedProduct: ProductAssembly;
  currentUser: string;
  onUpdateECO: (updatedECO: EngineeringChangeOrder) => void;
  onCreateECO: (newECO: EngineeringChangeOrder) => void;
  onSelectItem: (item: BOMItem) => void;
}

export const ChangeOrdersView: React.FC<ChangeOrdersViewProps> = ({
  ecos,
  products,
  selectedProduct,
  currentUser,
  onUpdateECO,
  onCreateECO,
  onSelectItem
}) => {
  const [selectedEcoId, setSelectedEcoId] = useState<string>(ecos[0]?.id || '');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [showNewEcoModal, setShowNewEcoModal] = useState(false);
  const [signoffComment, setSignoffComment] = useState('');
  const [signingRole, setSigningRole] = useState<string | null>(null);

  const selectedECO = ecos.find((e) => e.id === selectedEcoId) || ecos[0];

  const filteredECOs = ecos.filter((eco) => {
    if (statusFilter === 'All') return true;
    if (statusFilter === 'Pending') return eco.status === 'CCB Review' || eco.status === 'Technical Review';
    return eco.status === statusFilter;
  });

  // Handle user signing off on an ECO
  const handleSignoff = (roleName: string) => {
    if (!selectedECO) return;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const updatedSignoffs: ECOSignoff[] = selectedECO.signoffs.map((s) => {
      if (s.role === roleName) {
        return {
          ...s,
          signed: true,
          signedDate: now,
          comments: signoffComment.trim() || `Approved by ${currentUser}`
        };
      }
      return s;
    });

    // Check if all signed
    const allSigned = updatedSignoffs.every((s) => s.signed);
    const newStatus: ECOStatus = allSigned ? 'Approved' : selectedECO.status;

    const updated: EngineeringChangeOrder = {
      ...selectedECO,
      status: newStatus,
      signoffs: updatedSignoffs
    };

    onUpdateECO(updated);
    setSigningRole(null);
    setSignoffComment('');
  };

  const handleImplement = () => {
    if (!selectedECO) return;
    const updated: EngineeringChangeOrder = {
      ...selectedECO,
      status: 'Implemented'
    };
    onUpdateECO(updated);
  };

  // Stepper stages
  const stages: ECOStatus[] = ['Draft', 'Technical Review', 'CCB Review', 'Approved', 'Implemented'];
  const currentStageIndex = selectedECO ? stages.indexOf(selectedECO.status) : 0;

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              Engineering Governance
            </span>
            <span className="text-xs text-slate-500">·</span>
            <span className="text-xs text-slate-600 font-medium">Closed-Loop Change Control (CCB)</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 font-display">
            Engineering Change Orders (ECO / ECR)
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Formalize revisions, manage disposition of parts in inventory, and collect cross-departmental sign-offs.
          </p>
        </div>

        <button
          onClick={() => setShowNewEcoModal(true)}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Change Order</span>
        </button>
      </div>

      {/* Main Layout: Left ECO List, Right ECO Detailed Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: ECO Directory (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs border border-slate-200 overflow-x-auto">
            <button
              onClick={() => setStatusFilter('All')}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'All' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({ecos.length})
            </button>
            <button
              onClick={() => setStatusFilter('Pending')}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'Pending' ? 'bg-white text-amber-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              In Review
            </button>
            <button
              onClick={() => setStatusFilter('Approved')}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'Approved' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Approved
            </button>
            <button
              onClick={() => setStatusFilter('Implemented')}
              className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                statusFilter === 'Implemented' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Implemented
            </button>
          </div>

          {/* Cards List */}
          <div className="space-y-2.5">
            {filteredECOs.map((eco) => {
              const isSelected = eco.id === selectedECO?.id;
              const pendingCount = eco.signoffs.filter((s) => !s.signed).length;

              return (
                <div
                  key={eco.id}
                  onClick={() => setSelectedEcoId(eco.id)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-indigo-50/40 border-indigo-300 shadow-xs ring-1 ring-indigo-400/20'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-mono text-xs font-bold text-indigo-700">
                      {eco.ecoNumber}
                    </span>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                      eco.status === 'Approved'
                        ? 'bg-emerald-100/70 text-emerald-800'
                        : eco.status === 'Implemented'
                        ? 'bg-slate-200 text-slate-800'
                        : eco.status === 'CCB Review'
                        ? 'bg-amber-100/70 text-amber-800'
                        : 'bg-blue-100/70 text-blue-800'
                    }`}>
                      {eco.status}
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-slate-900 line-clamp-1 mb-1 font-display">
                    {eco.title}
                  </h3>

                  <p className="text-[11px] text-slate-500 line-clamp-2 mb-2.5">
                    {eco.reasonForChange}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                    <span className="font-mono">{eco.productName.split(' ')[0]}</span>
                    <span>
                      {pendingCount > 0 ? (
                        <span className="text-amber-700 font-medium">{pendingCount} approvals pending</span>
                      ) : (
                        <span className="text-emerald-700 font-medium">All approved</span>
                      )}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected ECO Inspector (8 cols) */}
        {selectedECO ? (
          <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-sm font-mono font-bold text-indigo-700">
                    {selectedECO.ecoNumber}
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-600 font-medium">
                    Priority: <span className={selectedECO.priority === 'Urgent' ? 'text-rose-600 font-bold' : 'text-slate-800'}>{selectedECO.priority}</span>
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-600 font-medium">
                    Category: {selectedECO.changeType}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-slate-900 font-display">
                  {selectedECO.title}
                </h2>
                <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                  <span>Product: <strong className="text-slate-800">{selectedECO.productName}</strong></span>
                  <span>·</span>
                  <span>Originator: {selectedECO.originator}</span>
                  <span>·</span>
                  <span>Target Date: {selectedECO.targetImplementationDate}</span>
                </div>
              </div>

              {selectedECO.status === 'Approved' && (
                <button
                  onClick={handleImplement}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 shadow-xs flex items-center gap-1.5 whitespace-nowrap self-start"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Release & Implement</span>
                </button>
              )}
            </div>

            {/* Visual Workflow Stepper */}
            <div>
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-3">
                Lifecycle Approval Progress
              </h4>
              <div className="flex items-center justify-between relative">
                {/* Connecting bar */}
                <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 z-0" />
                {stages.map((stage, idx) => {
                  const isDone = idx <= currentStageIndex;
                  const isCurrent = idx === currentStageIndex;
                  return (
                    <div key={stage} className="relative z-10 flex flex-col items-center">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isCurrent
                            ? 'bg-indigo-600 text-white ring-4 ring-indigo-100 shadow-xs'
                            : isDone
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border-2 border-slate-300 text-slate-400'
                        }`}
                      >
                        {isDone ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : idx + 1}
                      </div>
                      <span className={`text-[10px] mt-1.5 font-medium whitespace-nowrap ${
                        isCurrent ? 'text-indigo-600 font-bold' : isDone ? 'text-slate-800' : 'text-slate-400'
                      }`}>
                        {stage}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Financial & Scrap Impact Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div>
                <span className="text-xs text-slate-500 block mb-0.5">Net Unit Cost Impact</span>
                <span className={`text-base font-bold font-mono tabular-nums ${
                  selectedECO.netUnitCostImpact < 0 ? 'text-emerald-600' : 'text-slate-800'
                }`}>
                  {selectedECO.netUnitCostImpact < 0 ? `-$${Math.abs(selectedECO.netUnitCostImpact).toFixed(2)}` : `+$${selectedECO.netUnitCostImpact.toFixed(2)}`}
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">per manufactured unit</span>
              </div>

              <div>
                <span className="text-xs text-slate-500 block mb-0.5">Scrap & Write-Off Cost</span>
                <span className="text-base font-bold font-mono text-rose-600 tabular-nums">
                  ${selectedECO.totalScrapCost.toFixed(2)}
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">inventory impact</span>
              </div>

              <div className="col-span-2 sm:col-span-1">
                <span className="text-xs text-slate-500 block mb-0.5">Affected Components</span>
                <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                  {selectedECO.affectedItems.length} line items
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">redline revisions</span>
              </div>
            </div>

            {/* Reason and Description */}
            <div className="space-y-3 text-xs">
              <div>
                <h4 className="font-semibold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  Reason for Change
                </h4>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-800 leading-relaxed">
                  {selectedECO.reasonForChange}
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-slate-700 uppercase tracking-wider text-[11px] mb-1">
                  Detailed Engineering Scope & Work Instructions
                </h4>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-800 font-mono whitespace-pre-line leading-relaxed text-[11px]">
                  {selectedECO.descriptionOfChange}
                </div>
              </div>
            </div>

            {/* Affected Items Redline Table */}
            <div>
              <h4 className="font-semibold text-slate-700 uppercase tracking-wider text-[11px] mb-2 flex items-center justify-between">
                <span>Affected Items & Inventory Dispositions</span>
                <span className="text-slate-400 font-normal lowercase">({selectedECO.affectedItems.length} parts)</span>
              </h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase">
                    <tr>
                      <th className="py-2 px-3">Part #</th>
                      <th className="py-2 px-3">Description</th>
                      <th className="py-2 px-3 text-center">Rev Transition</th>
                      <th className="py-2 px-3">Disposition</th>
                      <th className="py-2 px-3 text-right">In Stock</th>
                      <th className="py-2 px-3 text-right">Scrap ($)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedECO.affectedItems.map((item) => (
                      <tr key={item.partId} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                          {item.partNumber}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-medium text-slate-800">{item.name}</div>
                          <div className="text-[11px] text-slate-500">{item.notes}</div>
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono">
                          <span className="text-slate-500 font-medium">Rev {item.fromRevision}</span>
                          <span className="mx-1 text-indigo-500 font-bold">→</span>
                          <span className="font-bold text-indigo-700 bg-indigo-50 px-1 py-0.5 rounded">Rev {item.toRevision}</span>
                        </td>
                        <td className="py-2.5 px-3 font-medium">
                          <span className={`px-2 py-0.5 rounded text-[11px] ${
                            item.disposition === 'Scrap Existing'
                              ? 'bg-rose-100 text-rose-800'
                              : item.disposition === 'Rework Existing'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {item.disposition}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {item.quantityInStock} pcs
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-900 font-medium">
                          ${item.scrapCost.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Interactive Sign-off Matrix */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-slate-700 uppercase tracking-wider text-[11px]">
                  Cross-Functional Approval Matrix
                </h4>
                <span className="text-xs text-slate-500">
                  Current User: <strong className="text-slate-800">{currentUser}</strong>
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedECO.signoffs.map((signoff) => (
                  <div
                    key={signoff.role}
                    className={`p-3.5 rounded-lg border text-xs transition-colors ${
                      signoff.signed
                        ? 'bg-emerald-50/40 border-emerald-200'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-bold text-slate-900">{signoff.role}</div>
                        <div className="text-slate-500 text-[11px]">
                          {signoff.assigneeName} · {signoff.assigneeTitle}
                        </div>
                      </div>
                      {signoff.signed ? (
                        <div className="flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-100/70 px-2 py-0.5 rounded text-[11px]">
                          <Check className="w-3.5 h-3.5" />
                          <span>Approved</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => setSigningRole(signoff.role)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-indigo-700 bg-white border border-indigo-200 rounded hover:bg-indigo-50 shadow-2xs transition-colors"
                        >
                          Sign / Review
                        </button>
                      )}
                    </div>

                    {signoff.signed && (
                      <div className="mt-2 pt-2 border-t border-emerald-100 text-[11px] text-slate-600">
                        <div className="text-emerald-800 font-medium">Signed: {signoff.signedDate}</div>
                        {signoff.comments && (
                          <div className="text-slate-600 italic mt-0.5">"{signoff.comments}"</div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Sign-off Modal / Drawer when user clicks to sign */}
            {signingRole && (
              <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-lg space-y-3 animate-in fade-in duration-150">
                <div className="flex items-center justify-between">
                  <h5 className="text-xs font-bold text-indigo-900">
                    Sign Off as <span className="underline">{signingRole}</span>
                  </h5>
                  <button
                    onClick={() => setSigningRole(null)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-slate-600">
                  By signing, you certify engineering review of affected items, disposition plans, and risk assessments.
                </p>
                <textarea
                  value={signoffComment}
                  onChange={(e) => setSignoffComment(e.target.value)}
                  placeholder="Enter sign-off comments, test fixture data, or vendor quotes..."
                  className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                  rows={2}
                />
                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setSigningRole(null)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleSignoff(signingRole)}
                    className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 shadow-2xs"
                  >
                    Confirm & Record Signature
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="lg:col-span-8 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500">
            No change order selected.
          </div>
        )}
      </div>

      {/* New ECO Creation Wizard Modal */}
      {showNewEcoModal && (
        <NewECOWizardModal
          product={selectedProduct}
          onClose={() => setShowNewEcoModal(false)}
          onCreate={(newEco) => {
            onCreateECO(newEco);
            setShowNewEcoModal(false);
            setSelectedEcoId(newEco.id);
          }}
          currentUser={currentUser}
        />
      )}
    </div>
  );
};

interface NewECOWizardModalProps {
  product: ProductAssembly;
  onClose: () => void;
  onCreate: (eco: EngineeringChangeOrder) => void;
  currentUser: string;
}

const NewECOWizardModal: React.FC<NewECOWizardModalProps> = ({
  product,
  onClose,
  onCreate,
  currentUser
}) => {
  const [title, setTitle] = useState('');
  const [changeType, setChangeType] = useState<EngineeringChangeOrder['changeType']>('Cost Reduction');
  const [priority, setPriority] = useState<ECOPriority>('Standard');
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [selectedPartId, setSelectedPartId] = useState('');
  const [disposition, setDisposition] = useState<Disposition>('Use As-Is');

  const flatParts = flattenBOM(product.bom);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !reason.trim()) return;

    const affectedPart = flatParts.find((p) => p.id === selectedPartId) || flatParts[0];

    const ecoNum = `ECO-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newEco: EngineeringChangeOrder = {
      id: ecoNum,
      ecoNumber: ecoNum,
      title,
      productId: product.id,
      productName: product.name,
      originator: currentUser,
      originatorEmail: 'engineering@kiteplm.io',
      status: 'CCB Review',
      priority,
      changeType,
      createdDate: new Date().toISOString().split('T')[0],
      targetImplementationDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
      reasonForChange: reason,
      descriptionOfChange: description || 'Redline revision implementation.',
      affectedItems: affectedPart ? [
        {
          partId: affectedPart.id,
          partNumber: affectedPart.partNumber,
          name: affectedPart.name,
          fromRevision: affectedPart.revision,
          toRevision: String.fromCharCode(affectedPart.revision.charCodeAt(0) + 1),
          disposition,
          quantityInStock: 250,
          scrapCost: disposition === 'Scrap Existing' ? affectedPart.unitCost * 250 : 0,
          notes: `Disposition: ${disposition}`
        }
      ] : [],
      totalScrapCost: disposition === 'Scrap Existing' && affectedPart ? affectedPart.unitCost * 250 : 0,
      netUnitCostImpact: -5.00,
      signoffs: [
        {
          role: 'Lead Mechanical',
          assigneeName: 'Sarah Chen',
          assigneeTitle: 'Principal Mechanical Architect',
          signed: false
        },
        {
          role: 'Lead Electrical',
          assigneeName: 'David Thorne',
          assigneeTitle: 'Lead Electrical Engineer',
          signed: false
        },
        {
          role: 'Supply Chain',
          assigneeName: 'Elena Vance',
          assigneeTitle: 'Director of Strategic Sourcing',
          signed: false
        },
        {
          role: 'Quality & Compliance',
          assigneeName: 'Marcus Rivera',
          assigneeTitle: 'Quality & Regulatory Manager',
          signed: false
        }
      ]
    };

    onCreate(newEco);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 font-display">Create Engineering Change Order</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">ECO Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Swapped Motor Driver due to Lead Time Extension"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Change Category</label>
              <select
                value={changeType}
                onChange={(e) => setChangeType(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="Cost Reduction">Cost Reduction</option>
                <option value="Reliability / Defect">Reliability / Defect</option>
                <option value="Obsolescence">Obsolescence</option>
                <option value="Feature Enhancement">Feature Enhancement</option>
                <option value="Regulatory">Regulatory</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="Standard">Standard</option>
                <option value="Urgent">Urgent</option>
                <option value="Low">Low</option>
                <option value="Mandatory Recall">Mandatory Recall</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Primary Affected Part</label>
            <select
              value={selectedPartId}
              onChange={(e) => setSelectedPartId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
            >
              <option value="">Select a part from active BOM...</option>
              {flatParts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.partNumber} · Rev {p.revision} · {p.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Inventory Disposition</label>
            <select
              value={disposition}
              onChange={(e) => setDisposition(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            >
              <option value="Use As-Is">Use As-Is (Deplete stock first)</option>
              <option value="Rework Existing">Rework Existing (Field/Line modification)</option>
              <option value="Scrap Existing">Scrap Existing (Immediate quarantine and write-off)</option>
              <option value="Phase-in at Serial #">Phase-in at Serial Number</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Engineering Problem Statement</label>
            <textarea
              required
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Why is this change necessary? (e.g. thermal overload, vendor EOL, weight target)"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Description of Change & Scope</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Work instructions, drawing revisions, and redline steps..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-hidden font-mono"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
            >
              Submit ECO for CCB Review
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
