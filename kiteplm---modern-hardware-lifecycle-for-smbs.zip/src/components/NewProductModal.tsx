import React, { useState } from 'react';
import { ProductAssembly, LifecycleStage } from '../types/plm';
import { Layers, X } from 'lucide-react';

interface NewProductModalProps {
  onClose: () => void;
  onCreate: (product: ProductAssembly) => void;
}

export const NewProductModal: React.FC<NewProductModalProps> = ({ onClose, onCreate }) => {
  const [sku, setSku] = useState('');
  const [name, setName] = useState('');
  const [codeName, setCodeName] = useState('');
  const [lifecycle, setLifecycle] = useState<LifecycleStage>('Concept');
  const [msrp, setMsrp] = useState('2400');
  const [annualVolume, setAnnualVolume] = useState('1000');
  const [targetMarket, setTargetMarket] = useState('Industrial & Commercial');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sku.trim() || !name.trim()) return;

    const prodId = `PRD-${Date.now().toString().slice(-4)}`;
    const newProduct: ProductAssembly = {
      id: prodId,
      sku: sku.toUpperCase(),
      name,
      codeName: codeName || 'ProjectAlpha',
      currentRevision: 'A',
      lifecycle,
      description,
      targetMarket,
      targetMSRP: parseFloat(msrp) || 0,
      estimatedAnnualVolume: parseInt(annualVolume) || 1000,
      createdDate: new Date().toISOString().split('T')[0],
      updatedDate: new Date().toISOString().split('T')[0],
      bom: [
        {
          id: `BOM-${Date.now()}`,
          partNumber: `ASM-${sku.toUpperCase()}-01`,
          name: `${name} Top Assembly`,
          revision: 'A',
          description: `Top-level assembly for ${name}`,
          category: 'Mechanical',
          quantity: 1,
          unitOfMeasure: 'ea',
          unitCost: 150.00,
          leadTimeWeeks: 4,
          lifecycle,
          sourcing: 'Custom Tooling',
          primarySupplier: 'Internal Integration',
          primaryMpn: `${sku.toUpperCase()}-SYS-01`,
          compliance: 'RoHS & REACH Compliant',
          amlList: [],
          parentId: null,
          level: 0,
          weightGrams: 500,
          children: []
        }
      ]
    };

    onCreate(newProduct);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden text-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 font-display text-sm">
              Create New Hardware Assembly Program
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Product SKU / ID</label>
              <input
                type="text"
                required
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. APX-X5"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Project Codename</label>
              <input
                type="text"
                value={codeName}
                onChange={(e) => setCodeName(e.target.value)}
                placeholder="e.g. Falcon"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Commercial Product Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. NextGen Autonomous Inspection Drone"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Lifecycle Stage</label>
              <select
                value={lifecycle}
                onChange={(e) => setLifecycle(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="Concept">Concept</option>
                <option value="Prototype">Prototype</option>
                <option value="EVT">EVT</option>
                <option value="DVT">DVT</option>
                <option value="PVT">PVT</option>
                <option value="Production">Production</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target MSRP ($)</label>
              <input
                type="number"
                value={msrp}
                onChange={(e) => setMsrp(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Est. Annual Vol</label>
              <input
                type="number"
                value={annualVolume}
                onChange={(e) => setAnnualVolume(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Target Market / Use Case</label>
            <input
              type="text"
              value={targetMarket}
              onChange={(e) => setTargetMarket(e.target.value)}
              placeholder="e.g. Defense, Medical Diagnostics, Oil & Gas"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Engineering objectives and high-level architectural constraints..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
            >
              Initialize Assembly
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
