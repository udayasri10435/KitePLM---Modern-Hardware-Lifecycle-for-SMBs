import React from 'react';
import { BOMItem, ProductAssembly, EngineeringChangeOrder } from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { X, ExternalLink, AlertTriangle, Layers, GitBranch } from 'lucide-react';

interface WhereUsedModalProps {
  item: BOMItem | null;
  products: ProductAssembly[];
  ecos: EngineeringChangeOrder[];
  onClose: () => void;
  onNavigateToProduct: (productId: string) => void;
  onOpenECO: (ecoId: string) => void;
}

export const WhereUsedModal: React.FC<WhereUsedModalProps> = ({
  item,
  products,
  ecos,
  onClose,
  onNavigateToProduct,
  onOpenECO
}) => {
  if (!item) return null;

  // Find all products and parent assemblies where this partNumber or MPN appears
  const usages: { product: ProductAssembly; parentName: string; qty: number }[] = [];
  
  products.forEach((prod) => {
    const flat = flattenBOM(prod.bom);
    flat.forEach((subItem) => {
      // Direct match or child match
      if (subItem.partNumber === item.partNumber) {
        // find parent item
        const parent = flat.find((p) => p.id === subItem.parentId);
        usages.push({
          product: prod,
          parentName: parent ? `${parent.partNumber} (${parent.name})` : 'Top Assembly Root',
          qty: subItem.quantity
        });
      }
    });
  });

  // Check if part is referenced in any active ECOs
  const relatedECOs = ecos.filter((eco) => 
    eco.affectedItems.some((aff) => aff.partNumber === item.partNumber)
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 font-display">
                Where-Used Reverse Dependency Lookup
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                {item.partNumber} · Rev {item.revision} · {item.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Summary Strip */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-xs text-slate-500 block">Total Assemblies</span>
              <span className="text-lg font-bold text-slate-900 font-mono tabular-nums">{usages.length}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-xs text-slate-500 block">Total Qty Consumed</span>
              <span className="text-lg font-bold text-indigo-600 font-mono tabular-nums">
                {usages.reduce((acc, u) => acc + u.qty, 0)} {item.unitOfMeasure}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-xs text-slate-500 block">Active Change Orders</span>
              <span className="text-lg font-bold text-amber-600 font-mono tabular-nums">{relatedECOs.length}</span>
            </div>
          </div>

          {/* Active Usage Tree */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <GitBranch className="w-3.5 h-3.5 text-indigo-600" />
              Direct Parent Assemblies & Products
            </h4>
            
            {usages.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-slate-200 rounded-lg text-slate-500 text-sm">
                This item is currently an unassigned standalone component.
              </div>
            ) : (
              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden">
                {usages.map((u, i) => (
                  <div key={i} className="p-3 hover:bg-slate-50 flex items-center justify-between text-sm transition-colors">
                    <div>
                      <div className="font-semibold text-slate-900 flex items-center gap-2">
                        <span>{u.product.sku}</span>
                        <span className="text-xs text-slate-500 font-normal">({u.product.name})</span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Installed in parent: <span className="font-medium text-slate-700">{u.parentName}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-mono font-medium text-slate-600 bg-slate-100 px-2 py-1 rounded">
                        Qty: {u.qty} {item.unitOfMeasure}
                      </span>
                      <button
                        onClick={() => {
                          onNavigateToProduct(u.product.id);
                          onClose();
                        }}
                        className="text-xs font-medium text-indigo-600 hover:text-indigo-800 flex items-center gap-1 hover:underline"
                      >
                        <span>View Product</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Related ECOs */}
          {relatedECOs.length > 0 && (
            <div className="border-t border-slate-100 pt-4">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-700 mb-2 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                Active Engineering Change Orders Affecting this Part
              </h4>
              <div className="space-y-2">
                {relatedECOs.map((eco) => (
                  <div key={eco.id} className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-lg flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-slate-900 flex items-center gap-2">
                        <span>{eco.ecoNumber}</span>
                        <span className="font-normal text-slate-600">{eco.title}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Status: <span className="font-semibold text-amber-800">{eco.status}</span> · Priority: {eco.priority}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        onOpenECO(eco.id);
                        onClose();
                      }}
                      className="px-2.5 py-1 text-xs font-medium text-indigo-700 bg-white border border-slate-200 rounded hover:bg-indigo-50"
                    >
                      Inspect ECO
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
