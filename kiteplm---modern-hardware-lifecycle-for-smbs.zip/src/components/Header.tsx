import React from 'react';
import { ProductAssembly } from '../types/plm';
import { Layers, GitCommit, FileText, Building2, Database, ChevronDown, Plus, Sparkles, UserCheck } from 'lucide-react';

export type NavTab = 'bom' | 'diff' | 'eco' | 'suppliers' | 'items';

interface HeaderProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  products: ProductAssembly[];
  selectedProduct: ProductAssembly;
  onSelectProduct: (product: ProductAssembly) => void;
  onOpenNewProduct: () => void;
  currentUser: string;
  onSwitchUser: () => void;
  isSupplierMode: boolean;
  onToggleSupplierMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  products,
  selectedProduct,
  onSelectProduct,
  onOpenNewProduct,
  currentUser,
  onSwitchUser,
  isSupplierMode,
  onToggleSupplierMode
}) => {
  const [productDropdownOpen, setProductDropdownOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* Strict 1-row, 3-zone Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand title, single line */}
        <div className="flex items-center gap-6 shrink-0">
          <button 
            onClick={() => onTabChange('bom')} 
            className="flex items-center gap-2 group text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold tracking-tight text-base group-hover:bg-indigo-600 transition-colors">
              K
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 font-display">
              Kite<span className="text-indigo-600">PLM</span>
            </span>
          </button>
        </div>

        {/* Zone 2: 4-6 Nav links, 1-2 word labels, single-line */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => onTabChange('bom')}
            className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'bom'
                ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>BOM Tree</span>
          </button>

          <button
            onClick={() => onTabChange('diff')}
            className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'diff'
                ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <GitCommit className="w-4 h-4" />
            <span>Revision Diff</span>
          </button>

          <button
            onClick={() => onTabChange('eco')}
            className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'eco'
                ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Change Orders</span>
          </button>

          <button
            onClick={() => onTabChange('suppliers')}
            className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'suppliers'
                ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Suppliers & AML</span>
          </button>

          <button
            onClick={() => onTabChange('items')}
            className={`px-3 py-2 text-sm font-medium rounded-md whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'items'
                ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Item Master</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Product Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setProductDropdownOpen(!productDropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-medium text-slate-800 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors border border-slate-200/80 max-w-[190px] sm:max-w-[240px]"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
              <span className="truncate">{selectedProduct.sku} · Rev {selectedProduct.currentRevision}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0 ml-auto" />
            </button>

            {productDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-30" 
                  onClick={() => setProductDropdownOpen(false)} 
                />
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border border-slate-200 py-1 z-40 text-xs sm:text-sm">
                  <div className="px-3 py-2 border-b border-slate-100 text-xs text-slate-500 font-semibold uppercase tracking-wider">
                    Select Assembly
                  </div>
                  {products.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        onSelectProduct(p);
                        setProductDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2.5 hover:bg-slate-50 flex flex-col gap-0.5 transition-colors ${
                        p.id === selectedProduct.id ? 'bg-indigo-50/60 text-indigo-900 font-medium' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900">{p.sku}</span>
                        <span className="text-[11px] font-mono text-slate-500">Rev {p.currentRevision} · {p.lifecycle}</span>
                      </div>
                      <span className="text-xs text-slate-500 truncate">{p.name}</span>
                    </button>
                  ))}
                  <div className="p-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setProductDropdownOpen(false);
                        onOpenNewProduct();
                      }}
                      className="w-full text-left px-3 py-2 text-indigo-600 hover:bg-indigo-50 font-medium rounded flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create New Product Assembly</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Supplier View Mode Toggle or Role Switcher */}
          <button
            onClick={onToggleSupplierMode}
            className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              isSupplierMode
                ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
            title="Toggle between Internal Engineering and External Supplier Portal"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isSupplierMode ? 'Supplier View: Novatronics' : 'Supplier Portal'}</span>
            <span className="sm:hidden">{isSupplierMode ? 'Supplier' : 'Portal'}</span>
          </button>

          {/* User Persona Switcher */}
          <button
            onClick={onSwitchUser}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-transparent hover:border-slate-200 transition-colors"
            title="Switch User Persona (EE Lead, ME Lead, Sourcing, Quality)"
          >
            <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden lg:inline">{currentUser}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
