import React, { useState } from 'react';
import { BOMItem, AMLVendor, ComplianceStatus } from '../types/plm';
import { CADPreview } from './CADPreview';
import { 
  X, 
  ShieldCheck, 
  Clock, 
  DollarSign, 
  Scale, 
  ExternalLink, 
  Building2, 
  Plus, 
  Check, 
  FileText,
  AlertCircle,
  FileCheck2
} from 'lucide-react';

interface PartDetailDrawerProps {
  item: BOMItem | null;
  onClose: () => void;
  onOpenWhereUsed: (item: BOMItem) => void;
  onInitiateECO: (item: BOMItem) => void;
  onUpdateItemAML?: (itemId: string, updatedAML: AMLVendor[]) => void;
}

export const PartDetailDrawer: React.FC<PartDetailDrawerProps> = ({
  item,
  onClose,
  onOpenWhereUsed,
  onInitiateECO,
  onUpdateItemAML
}) => {
  const [activeTab, setActiveTab] = useState<'specs' | 'aml' | 'compliance' | 'drawings'>('specs');
  const [showAddAMLModal, setShowAddAMLModal] = useState(false);
  const [newVendorName, setNewVendorName] = useState('');
  const [newMpn, setNewMpn] = useState('');
  const [newUnitCost, setNewUnitCost] = useState('15.00');
  const [newLeadTime, setNewLeadTime] = useState('4');

  if (!item) return null;

  const handleAddVendor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVendorName || !newMpn) return;

    const newVendor: AMLVendor = {
      vendorId: `SUP-${Date.now()}`,
      vendorName: newVendorName,
      mpn: newMpn,
      isPreferred: item.amlList.length === 0,
      unitCost: parseFloat(newUnitCost) || 0,
      leadTimeWeeks: parseInt(newLeadTime) || 4,
      moq: 100,
      packaging: 'Standard Packaging',
      compliance: 'RoHS & REACH Compliant'
    };

    const updated = [...item.amlList, newVendor];
    if (onUpdateItemAML) {
      onUpdateItemAML(item.id, updated);
    }
    setShowAddAMLModal(false);
    setNewVendorName('');
    setNewMpn('');
  };

  const handleSetPreferred = (vendorId: string) => {
    const updated = item.amlList.map((v) => ({
      ...v,
      isPreferred: v.vendorId === vendorId
    }));
    if (onUpdateItemAML) {
      onUpdateItemAML(item.id, updated);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-xl bg-white shadow-2xl flex flex-col h-full border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-2 py-0.5 rounded">
                {item.partNumber}
              </span>
              <span className="text-xs font-mono text-slate-500 font-medium">
                Rev {item.revision}
              </span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs font-medium text-slate-600 bg-slate-200/70 px-2 py-0.5 rounded">
                {item.category}
              </span>
            </div>
            <h2 className="text-lg font-bold text-slate-900 font-display leading-snug">
              {item.name}
            </h2>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              {item.description}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-200 bg-white">
          <button
            onClick={() => setActiveTab('specs')}
            className={`px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'specs'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Engineering Specs
          </button>
          <button
            onClick={() => setActiveTab('aml')}
            className={`px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'aml'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Approved Vendors (AML) ({item.amlList?.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('compliance')}
            className={`px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
              activeTab === 'compliance'
                ? 'border-indigo-600 text-indigo-600 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Compliance & Certs
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'specs' && (
            <>
              {/* CAD Blueprint Schematic */}
              <div>
                <CADPreview
                  partNumber={item.partNumber}
                  name={item.name}
                  category={item.category}
                  revision={item.revision}
                />
              </div>

              {/* Quick Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Unit Cost</span>
                  </div>
                  <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                    ${item.unitCost.toFixed(2)}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <Clock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Lead Time</span>
                  </div>
                  <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                    {item.leadTimeWeeks} wks
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <Scale className="w-3.5 h-3.5 text-slate-600" />
                    <span>Est. Weight</span>
                  </div>
                  <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                    {item.weightGrams ? `${item.weightGrams}g` : 'N/A'}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Lifecycle</span>
                  </div>
                  <span className="text-xs font-semibold text-indigo-700 block mt-1">
                    {item.lifecycle}
                  </span>
                </div>
              </div>

              {/* Technical Attributes Table */}
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <div className="bg-slate-50 px-4 py-2.5 border-b border-slate-200 text-xs font-semibold uppercase tracking-wider text-slate-600">
                  Master Item Record
                </div>
                <div className="divide-y divide-slate-100 text-xs">
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-500">Primary MPN</span>
                    <span className="font-mono font-medium text-slate-900">{item.primaryMpn || 'N/A'}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-500">Primary Supplier</span>
                    <span className="font-medium text-slate-900">{item.primarySupplier || 'In-House'}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-500">Sourcing Classification</span>
                    <span className={`font-medium ${item.sourcing === 'Single Source' ? 'text-amber-600' : 'text-slate-900'}`}>
                      {item.sourcing}
                    </span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-500">Unit of Measure</span>
                    <span className="font-medium text-slate-900 font-mono">{item.unitOfMeasure}</span>
                  </div>
                  <div className="px-4 py-2.5 flex justify-between">
                    <span className="text-slate-500">Compliance Standard</span>
                    <span className="font-medium text-emerald-700">{item.compliance}</span>
                  </div>
                </div>
              </div>

              {/* Where Used Quick Action */}
              <div className="p-4 bg-indigo-50/50 rounded-lg border border-indigo-100 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-indigo-900">Check Assembly Dependencies</h4>
                  <p className="text-xs text-indigo-700/80">
                    Inspect all parent assemblies and products that consume this part.
                  </p>
                </div>
                <button
                  onClick={() => onOpenWhereUsed(item)}
                  className="px-3 py-1.5 text-xs font-medium text-indigo-600 bg-white border border-indigo-200 rounded-lg hover:bg-indigo-50 shadow-xs flex items-center gap-1.5"
                >
                  <span>Where-Used</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>
            </>
          )}

          {activeTab === 'aml' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Approved Manufacturer List (AML / AVL)
                  </h4>
                  <p className="text-xs text-slate-500">
                    Multi-source qualification avoids supply chain shutdowns.
                  </p>
                </div>
                <button
                  onClick={() => setShowAddAMLModal(true)}
                  className="px-2.5 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 border border-indigo-200 rounded-md hover:bg-indigo-100 flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Alternate Vendor</span>
                </button>
              </div>

              {item.amlList && item.amlList.length > 0 ? (
                <div className="space-y-3">
                  {item.amlList.map((vendor) => (
                    <div 
                      key={vendor.vendorId}
                      className={`p-4 rounded-lg border transition-all ${
                        vendor.isPreferred
                          ? 'border-indigo-300 bg-indigo-50/30'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-slate-900 text-sm">{vendor.vendorName}</span>
                            {vendor.isPreferred ? (
                              <span className="text-[10px] uppercase font-bold text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded">
                                Preferred Source
                              </span>
                            ) : (
                              <button
                                onClick={() => handleSetPreferred(vendor.vendorId)}
                                className="text-[10px] text-slate-500 hover:text-indigo-600 hover:underline"
                              >
                                Set as Preferred
                              </button>
                            )}
                          </div>
                          <div className="text-xs font-mono text-slate-600 mt-1">
                            MPN: <span className="font-semibold text-slate-900">{vendor.mpn}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-bold font-mono text-slate-900 tabular-nums">
                            ${vendor.unitCost.toFixed(2)}
                          </span>
                          <span className="text-xs text-slate-500 block font-mono">
                            {vendor.leadTimeWeeks} wks lead time
                          </span>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <span>MOQ: <span className="font-mono text-slate-700 font-medium">{vendor.moq} pcs</span></span>
                        <span>Packaging: <span className="text-slate-700">{vendor.packaging}</span></span>
                        <span className="text-emerald-700 font-medium">{vendor.compliance}</span>
                      </div>

                      {vendor.notes && (
                        <div className="mt-2 text-xs text-amber-700 bg-amber-50 p-2 rounded border border-amber-200/60">
                          {vendor.notes}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center border border-dashed border-slate-200 rounded-lg text-slate-500 text-xs">
                  No alternate manufacturers configured. Add an alternate source to mitigate single-source risk.
                </div>
              )}

              {/* Add AML Form Modal */}
              {showAddAMLModal && (
                <form onSubmit={handleAddVendor} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
                  <h5 className="text-xs font-bold text-slate-900">Add Alternate Source / Vendor</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-slate-600 mb-1">Manufacturer / Vendor</label>
                      <input
                        type="text"
                        required
                        value={newVendorName}
                        onChange={(e) => setNewVendorName(e.target.value)}
                        placeholder="e.g. DigiKey / TDK / Arrow"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1">Vendor MPN</label>
                      <input
                        type="text"
                        required
                        value={newMpn}
                        onChange={(e) => setNewMpn(e.target.value)}
                        placeholder="e.g. IC-42688-ALT"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-900 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1">Unit Cost ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={newUnitCost}
                        onChange={(e) => setNewUnitCost(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-900 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 mb-1">Lead Time (Weeks)</label>
                      <input
                        type="number"
                        required
                        value={newLeadTime}
                        onChange={(e) => setNewLeadTime(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded text-slate-900 font-mono"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddAMLModal(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded hover:bg-indigo-700"
                    >
                      Save Alternate
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {activeTab === 'compliance' && (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-lg flex items-start gap-3">
                <FileCheck2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-emerald-900">RoHS 3 & EU REACH SVHC Compliant</h4>
                  <p className="text-xs text-emerald-700/90 mt-0.5">
                    Verified Lead-free (Pb &lt; 0.1%), Cadmium-free, and contains no SVHC substances exceeding 0.1% w/w under Regulation (EC) 1907/2006.
                  </p>
                </div>
              </div>

              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 text-xs">
                <div className="p-3 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-900 block">Declaration of Conformity (DoC)</span>
                    <span className="text-slate-500 text-[11px]">Audit Certificate #DOC-2026-9042</span>
                  </div>
                  <span className="text-emerald-700 font-medium">Valid until 2028</span>
                </div>

                <div className="p-3 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-900 block">Conflict Minerals Reporting (CMRT 6.3)</span>
                    <span className="text-slate-500 text-[11px]">3TG (Tantalum, Tin, Tungsten, Gold) Smelter Audited</span>
                  </div>
                  <span className="text-emerald-700 font-medium">Conformant</span>
                </div>

                <div className="p-3 flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-900 block">Flammability Rating</span>
                    <span className="text-slate-500 text-[11px]">UL94-V0 Vertical Flame Test</span>
                  </div>
                  <span className="text-slate-700 font-mono">Passed</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Drawer Footer Actions */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={() => onOpenWhereUsed(item)}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 flex items-center gap-1.5"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Where-Used</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onInitiateECO(item)}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Initiate Change Order (ECO)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
