import React, { useState } from 'react';
import { SupplierProfile, SupplierRFQ, ProductAssembly, BOMItem } from '../types/plm';
import { flattenBOM } from '../data/initialData';
import { 
  Building2, 
  Send, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  DollarSign, 
  FileText, 
  Plus, 
  Star, 
  ExternalLink,
  Download,
  AlertTriangle,
  ArrowRight,
  TrendingDown,
  X
} from 'lucide-react';

interface SupplierPortalViewProps {
  suppliers: SupplierProfile[];
  rfqs: SupplierRFQ[];
  products: ProductAssembly[];
  selectedProduct: ProductAssembly;
  isSupplierMode: boolean;
  onToggleSupplierMode: () => void;
  onUpdateRFQ: (updatedRFQ: SupplierRFQ) => void;
  onCreateRFQ: (newRFQ: SupplierRFQ) => void;
  onSelectItem: (item: BOMItem) => void;
}

export const SupplierPortalView: React.FC<SupplierPortalViewProps> = ({
  suppliers,
  rfqs,
  products,
  selectedProduct,
  isSupplierMode,
  onToggleSupplierMode,
  onUpdateRFQ,
  onCreateRFQ,
  onSelectItem
}) => {
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>(suppliers[0]?.id || '');
  const [showNewRfqModal, setShowNewRfqModal] = useState(false);
  const [editingQuoteRfq, setEditingQuoteRfq] = useState<SupplierRFQ | null>(null);

  // Supplier mode state (acting as Novatronics or Apex)
  const currentActingSupplier = suppliers.find((s) => s.id === 'SUP-02') || suppliers[0];

  // RFQs relevant to current supplier or all
  const displayedRFQs = isSupplierMode
    ? rfqs.filter((r) => r.supplierId === currentActingSupplier.id)
    : rfqs;

  const handleAwardRFQ = (rfq: SupplierRFQ) => {
    onUpdateRFQ({
      ...rfq,
      status: 'Awarded'
    });
  };

  const handleSaveSupplierQuote = (rfq: SupplierRFQ, quotedPrice: number, leadTime: number, notes: string) => {
    onUpdateRFQ({
      ...rfq,
      status: 'Quoted',
      quotedPrice,
      quotedLeadTimeWeeks: leadTime,
      quoteNotes: notes,
      tierPricing: [
        { qty: Math.round(rfq.requestedQty * 0.25), price: quotedPrice * 1.18 },
        { qty: rfq.requestedQty, price: quotedPrice },
        { qty: rfq.requestedQty * 5, price: quotedPrice * 0.88 }
      ]
    });
    setEditingQuoteRfq(null);
  };

  return (
    <div className="space-y-6">
      {/* Mode Banner */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
        isSupplierMode
          ? 'bg-amber-500/10 border-amber-300 text-amber-900'
          : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg shrink-0 ${
            isSupplierMode ? 'bg-amber-500 text-white' : 'bg-indigo-50 text-indigo-600'
          }`}>
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider">
                {isSupplierMode ? 'External Supplier Portal Simulator' : 'Internal Sourcing & AML Management'}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200/80 text-slate-800 font-mono font-medium">
                {isSupplierMode ? `Logged in as: ${currentActingSupplier.name}` : 'OEM Engineering View'}
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              {isSupplierMode
                ? 'External suppliers see only their assigned RFQs, can inspect drawing specs, and submit tiered quote pricing without enterprise license fees.'
                : 'Manage Approved Vendor Lists (AVL), compare supplier quote responses, and dispatch RFQs.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onToggleSupplierMode}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
              isSupplierMode
                ? 'bg-amber-600 text-white border-transparent hover:bg-amber-700'
                : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
            }`}
          >
            {isSupplierMode ? 'Switch to Internal View' : 'Simulate Supplier View'}
          </button>
          {!isSupplierMode && (
            <button
              onClick={() => setShowNewRfqModal(true)}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Dispatch New RFQ</span>
            </button>
          )}
        </div>
      </div>

      {/* Supplier Grid or Supplier's Active Quotes */}
      {!isSupplierMode ? (
        <>
          {/* Supplier Directory Cards */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 font-display">
                Approved Manufacturers & Vendors (AML / AVL)
              </h2>
              <span className="text-xs text-slate-500">
                {suppliers.length} Qualified Strategic Partners
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {suppliers.map((sup) => (
                <div
                  key={sup.id}
                  className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-indigo-300 transition-all space-y-3"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[11px] font-mono font-medium text-slate-500">
                        {sup.id} · {sup.category}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 font-display mt-0.5">
                        {sup.name}
                      </h3>
                      <p className="text-xs text-slate-500">{sup.location}</p>
                    </div>
                    <div className="flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/80 text-amber-800 text-xs font-bold">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                      <span>{sup.rating.toFixed(1)}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {sup.isoCertifications.map((cert) => (
                      <span
                        key={cert}
                        className="text-[10px] font-medium bg-slate-100 text-slate-700 px-2 py-0.5 rounded"
                      >
                        {cert}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 text-xs">
                    <div>
                      <span className="text-slate-500 text-[11px] block">Assigned Parts</span>
                      <span className="font-bold text-slate-900 font-mono tabular-nums">{sup.assignedPartsCount} items</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">Avg Lead Time</span>
                      <span className="font-bold text-slate-900 font-mono tabular-nums">{sup.averageLeadTimeWeeks} weeks</span>
                    </div>
                  </div>

                  <div className="pt-2 flex items-center justify-between text-xs">
                    <span className="text-emerald-700 font-medium flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      NDA {sup.ndaStatus}
                    </span>
                    <button
                      onClick={() => {
                        setSelectedSupplierId(sup.id);
                        setShowNewRfqModal(true);
                      }}
                      className="text-indigo-600 hover:text-indigo-800 font-medium hover:underline"
                    >
                      Request Quote →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : null}

      {/* RFQ & Quote Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 font-display">
              {isSupplierMode ? 'My Active RFQ Bid Requests' : 'Requests for Quote (RFQ) & Cost Comparisons'}
            </h3>
            <p className="text-xs text-slate-500">
              {isSupplierMode
                ? 'Review OEM specifications, download drawing packages, and enter price breaks.'
                : 'Compare quotes across suppliers and award manufacturing lots.'}
            </p>
          </div>
          <span className="text-xs font-mono font-medium text-slate-500">
            {displayedRFQs.length} RFQ records
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100/60 border-b border-slate-200 text-[11px] font-semibold text-slate-600 uppercase">
                <th className="py-2.5 px-3">RFQ #</th>
                <th className="py-2.5 px-3">Part # & Name</th>
                <th className="py-2.5 px-3">Supplier</th>
                <th className="py-2.5 px-3 text-right">Target Qty</th>
                <th className="py-2.5 px-3 text-right">Target ($)</th>
                <th className="py-2.5 px-3 text-right">Quoted ($)</th>
                <th className="py-2.5 px-3 text-right">Lead Time</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayedRFQs.map((rfq) => (
                <tr key={rfq.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-indigo-700 whitespace-nowrap">
                    {rfq.rfqNumber}
                  </td>

                  <td className="py-3 px-3">
                    <div className="font-mono font-semibold text-slate-900">{rfq.partNumber}</div>
                    <div className="text-slate-500 text-[11px] truncate max-w-xs">{rfq.partName}</div>
                  </td>

                  <td className="py-3 px-3 whitespace-nowrap">
                    <div className="font-medium text-slate-800">{rfq.supplierName}</div>
                    <div className="text-slate-400 text-[10px]">{rfq.supplierContact}</div>
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap font-medium text-slate-800">
                    {rfq.requestedQty.toLocaleString()} pcs
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-600">
                    ${rfq.targetPrice.toFixed(2)}
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap font-bold text-slate-900">
                    {rfq.quotedPrice ? (
                      <span className={rfq.quotedPrice <= rfq.targetPrice ? 'text-emerald-700' : 'text-slate-900'}>
                        ${rfq.quotedPrice.toFixed(2)}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic font-normal">Awaiting Bid</span>
                    )}
                  </td>

                  <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap text-slate-700">
                    {rfq.quotedLeadTimeWeeks ? `${rfq.quotedLeadTimeWeeks} wks` : '—'}
                  </td>

                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      rfq.status === 'Awarded'
                        ? 'bg-emerald-100 text-emerald-800'
                        : rfq.status === 'Quoted'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {rfq.status}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-right whitespace-nowrap">
                    {isSupplierMode ? (
                      <button
                        onClick={() => setEditingQuoteRfq(rfq)}
                        className="px-2.5 py-1 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded hover:bg-amber-100"
                      >
                        Submit / Edit Quote
                      </button>
                    ) : (
                      <div className="flex items-center justify-end gap-1.5">
                        {rfq.status === 'Quoted' && (
                          <button
                            onClick={() => handleAwardRFQ(rfq)}
                            className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 shadow-2xs"
                          >
                            Award Lot
                          </button>
                        )}
                        {rfq.status === 'Awarded' && (
                          <span className="text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Awarded
                          </span>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Supplier Submit Quote Modal (Interactive) */}
      {editingQuoteRfq && (
        <SupplierSubmitQuoteModal
          rfq={editingQuoteRfq}
          onClose={() => setEditingQuoteRfq(null)}
          onSave={(price, leadTime, notes) => handleSaveSupplierQuote(editingQuoteRfq, price, leadTime, notes)}
        />
      )}

      {/* New RFQ Dispatch Modal */}
      {showNewRfqModal && (
        <NewRFQModal
          suppliers={suppliers}
          initialSupplierId={selectedSupplierId}
          product={selectedProduct}
          onClose={() => setShowNewRfqModal(false)}
          onCreate={(rfq) => {
            onCreateRFQ(rfq);
            setShowNewRfqModal(false);
          }}
        />
      )}
    </div>
  );
};

interface SupplierSubmitQuoteModalProps {
  rfq: SupplierRFQ;
  onClose: () => void;
  onSave: (price: number, leadTime: number, notes: string) => void;
}

const SupplierSubmitQuoteModal: React.FC<SupplierSubmitQuoteModalProps> = ({
  rfq,
  onClose,
  onSave
}) => {
  const [price, setPrice] = useState(rfq.quotedPrice?.toString() || rfq.targetPrice.toString());
  const [leadTime, setLeadTime] = useState(rfq.quotedLeadTimeWeeks?.toString() || '4');
  const [notes, setNotes] = useState(rfq.quoteNotes || 'Includes lot certification and RoHS conformity.');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(parseFloat(price) || 0, parseInt(leadTime) || 4, notes);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden text-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-amber-50">
          <div>
            <h3 className="font-bold text-amber-900 font-display text-sm">
              Submit Supplier Quote Bid
            </h3>
            <p className="text-amber-700 font-mono text-[11px]">
              {rfq.rfqNumber} · {rfq.partNumber} ({rfq.partName})
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Lot Quantity</label>
              <div className="p-2 bg-slate-100 rounded border border-slate-200 font-mono text-slate-800">
                {rfq.requestedQty.toLocaleString()} pcs
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">OEM Target Price</label>
              <div className="p-2 bg-slate-100 rounded border border-slate-200 font-mono text-slate-800">
                ${rfq.targetPrice.toFixed(2)} / pc
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Your Quoted Unit Price ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Production Lead Time (Weeks)</label>
              <input
                type="number"
                required
                value={leadTime}
                onChange={(e) => setLeadTime(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono focus:ring-1 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Supplier Notes / Tier Price Conditions</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-700"
            >
              Submit Binding Quote
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface NewRFQModalProps {
  suppliers: SupplierProfile[];
  initialSupplierId?: string;
  product: ProductAssembly;
  onClose: () => void;
  onCreate: (rfq: SupplierRFQ) => void;
}

const NewRFQModal: React.FC<NewRFQModalProps> = ({
  suppliers,
  initialSupplierId,
  product,
  onClose,
  onCreate
}) => {
  const [supplierId, setSupplierId] = useState(initialSupplierId || suppliers[0]?.id || '');
  const [partId, setPartId] = useState('');
  const [requestedQty, setRequestedQty] = useState('500');
  const [targetPrice, setTargetPrice] = useState('50.00');

  const flatParts = flattenBOM(product.bom);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sup = suppliers.find((s) => s.id === supplierId);
    const part = flatParts.find((p) => p.id === partId);
    if (!sup || !part) return;

    const rfqNum = `RFQ-2026-${Math.floor(810 + Math.random() * 90)}`;
    const newRfq: SupplierRFQ = {
      id: rfqNum,
      rfqNumber: rfqNum,
      supplierId: sup.id,
      supplierName: sup.name,
      supplierContact: sup.contactEmail,
      partId: part.id,
      partNumber: part.partNumber,
      partName: part.name,
      status: 'Open',
      requestedQty: parseInt(requestedQty) || 500,
      targetPrice: parseFloat(targetPrice) || 0,
      createdDate: new Date().toISOString().split('T')[0]
    };

    onCreate(newRfq);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden text-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Send className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900 font-display text-sm">
              Dispatch Request for Quote (RFQ)
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Target Supplier</label>
            <select
              value={supplierId}
              onChange={(e) => setSupplierId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900"
            >
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.category} · {s.location})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Part / Subassembly to Quote</label>
            <select
              required
              value={partId}
              onChange={(e) => {
                setPartId(e.target.value);
                const selected = flatParts.find((p) => p.id === e.target.value);
                if (selected) {
                  setTargetPrice((selected.unitCost * 0.9).toFixed(2));
                }
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
            >
              <option value="">Select BOM item...</option>
              {flatParts.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.partNumber} · Rev {p.revision} · {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Lot Quantity</label>
              <input
                type="number"
                required
                value={requestedQty}
                onChange={(e) => setRequestedQty(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Unit Price ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700"
            >
              Send RFQ to Supplier
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
