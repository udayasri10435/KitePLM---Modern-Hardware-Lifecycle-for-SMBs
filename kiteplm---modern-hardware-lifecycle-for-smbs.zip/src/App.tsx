import React, { useState, useEffect } from 'react';
import { 
  ProductAssembly, 
  BOMItem, 
  EngineeringChangeOrder, 
  SupplierRFQ, 
  SupplierProfile, 
  BOMRevisionSnapshot,
  AMLVendor
} from './types/plm';
import { 
  initialProducts, 
  initialRevisions, 
  initialECOs, 
  initialSuppliers, 
  initialRFQs, 
  findBOMItem, 
  flattenBOM 
} from './data/initialData';
import { Header, NavTab } from './components/Header';
import { BOMView } from './components/BOMView';
import { RevisionDiffView } from './components/RevisionDiffView';
import { ChangeOrdersView } from './components/ChangeOrdersView';
import { SupplierPortalView } from './components/SupplierPortalView';
import { ItemMasterView } from './components/ItemMasterView';
import { PartDetailDrawer } from './components/PartDetailDrawer';
import { WhereUsedModal } from './components/WhereUsedModal';
import { NewProductModal } from './components/NewProductModal';
import { NewBOMItemModal } from './components/NewBOMItemModal';

const USER_ROLES = [
  'David Thorne (Principal EE)',
  'Sarah Chen (Lead Mechanical)',
  'Elena Vance (Supply Chain)',
  'Marcus Rivera (Quality & Compliance)'
];

export default function App() {
  // Products state
  const [products, setProducts] = useState<ProductAssembly[]>(() => {
    const saved = localStorage.getItem('kiteplm_products');
    return saved ? JSON.parse(saved) : initialProducts;
  });

  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || 'PRD-1001');
  const [activeTab, setActiveTab] = useState<NavTab>('bom');

  // Revisions state
  const [revisions, setRevisions] = useState<BOMRevisionSnapshot[]>(() => {
    const saved = localStorage.getItem('kiteplm_revisions');
    return saved ? JSON.parse(saved) : initialRevisions;
  });

  // Change Orders state
  const [ecos, setEcos] = useState<EngineeringChangeOrder[]>(() => {
    const saved = localStorage.getItem('kiteplm_ecos');
    return saved ? JSON.parse(saved) : initialECOs;
  });

  // Suppliers & RFQs state
  const [suppliers, setSuppliers] = useState<SupplierProfile[]>(() => {
    const saved = localStorage.getItem('kiteplm_suppliers');
    return saved ? JSON.parse(saved) : initialSuppliers;
  });

  const [rfqs, setRfqs] = useState<SupplierRFQ[]>(() => {
    const saved = localStorage.getItem('kiteplm_rfqs');
    return saved ? JSON.parse(saved) : initialRFQs;
  });

  // Modals & Drawer state
  const [selectedItemForDetail, setSelectedItemForDetail] = useState<BOMItem | null>(null);
  const [selectedItemForWhereUsed, setSelectedItemForWhereUsed] = useState<BOMItem | null>(null);
  const [showNewProductModal, setShowNewProductModal] = useState(false);
  const [showNewBOMItemModal, setShowNewBOMItemModal] = useState(false);
  const [targetParentForNewItem, setTargetParentForNewItem] = useState<BOMItem | undefined>(undefined);

  // User persona & Supplier Portal View mode
  const [currentUserIndex, setCurrentUserIndex] = useState(0);
  const [isSupplierMode, setIsSupplierMode] = useState(false);

  const currentUser = USER_ROLES[currentUserIndex];

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('kiteplm_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('kiteplm_ecos', JSON.stringify(ecos));
  }, [ecos]);

  useEffect(() => {
    localStorage.setItem('kiteplm_rfqs', JSON.stringify(rfqs));
  }, [rfqs]);

  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const handleSwitchUser = () => {
    setCurrentUserIndex((prev) => (prev + 1) % USER_ROLES.length);
  };

  const handleToggleSupplierMode = () => {
    const newMode = !isSupplierMode;
    setIsSupplierMode(newMode);
    if (newMode) {
      setActiveTab('suppliers');
    }
  };

  // Add Item to BOM handler
  const handleAddBOMItem = (newItem: BOMItem, targetParentId: string | null) => {
    const updatedProducts = products.map((prod) => {
      if (prod.id !== selectedProduct.id) return prod;

      // Helper to recursively insert child into target parent
      const insertChild = (items: BOMItem[]): BOMItem[] => {
        return items.map((item) => {
          if (item.id === targetParentId) {
            return {
              ...item,
              children: [...(item.children || []), newItem]
            };
          }
          if (item.children && item.children.length > 0) {
            return {
              ...item,
              children: insertChild(item.children)
            };
          }
          return item;
        });
      };

      let newBOM: BOMItem[];
      if (!targetParentId) {
        newBOM = [...prod.bom, newItem];
      } else {
        newBOM = insertChild(prod.bom);
      }

      return {
        ...prod,
        bom: newBOM,
        updatedDate: new Date().toISOString().split('T')[0]
      };
    });

    setProducts(updatedProducts);
    setShowNewBOMItemModal(false);
  };

  // Delete BOM Item handler
  const handleDeleteBOMItem = (itemId: string) => {
    const updatedProducts = products.map((prod) => {
      if (prod.id !== selectedProduct.id) return prod;

      const removeRecursive = (items: BOMItem[]): BOMItem[] => {
        return items
          .filter((item) => item.id !== itemId)
          .map((item) => ({
            ...item,
            children: item.children ? removeRecursive(item.children) : []
          }));
      };

      return {
        ...prod,
        bom: removeRecursive(prod.bom)
      };
    });

    setProducts(updatedProducts);
  };

  // Update item AML list
  const handleUpdateItemAML = (itemId: string, updatedAML: AMLVendor[]) => {
    const updateRecursive = (items: BOMItem[]): BOMItem[] => {
      return items.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            amlList: updatedAML
          };
        }
        if (item.children && item.children.length > 0) {
          return {
            ...item,
            children: updateRecursive(item.children)
          };
        }
        return item;
      });
    };

    setProducts((prev) =>
      prev.map((prod) => ({
        ...prod,
        bom: updateRecursive(prod.bom)
      }))
    );

    // Also update currently inspected item
    if (selectedItemForDetail && selectedItemForDetail.id === itemId) {
      setSelectedItemForDetail({
        ...selectedItemForDetail,
        amlList: updatedAML
      });
    }
  };

  // ECO updates
  const handleUpdateECO = (updatedECO: EngineeringChangeOrder) => {
    setEcos((prev) => prev.map((e) => (e.id === updatedECO.id ? updatedECO : e)));
  };

  const handleCreateECO = (newECO: EngineeringChangeOrder) => {
    setEcos((prev) => [newECO, ...prev]);
  };

  // RFQ updates
  const handleUpdateRFQ = (updatedRFQ: SupplierRFQ) => {
    setRfqs((prev) => prev.map((r) => (r.id === updatedRFQ.id ? updatedRFQ : r)));
  };

  const handleCreateRFQ = (newRFQ: SupplierRFQ) => {
    setRfqs((prev) => [newRFQ, ...prev]);
  };

  // Initiate ECO from a specific part
  const handleInitiateECOForPart = (item: BOMItem) => {
    setActiveTab('eco');
    // close drawers
    setSelectedItemForDetail(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Bar Contract compliant Navigation */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        products={products}
        selectedProduct={selectedProduct}
        onSelectProduct={(p) => setSelectedProductId(p.id)}
        onOpenNewProduct={() => setShowNewProductModal(true)}
        currentUser={currentUser}
        onSwitchUser={handleSwitchUser}
        isSupplierMode={isSupplierMode}
        onToggleSupplierMode={handleToggleSupplierMode}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'bom' && (
          <BOMView
            product={selectedProduct}
            onSelectItem={(item) => setSelectedItemForDetail(item)}
            onOpenWhereUsed={(item) => setSelectedItemForWhereUsed(item)}
            onOpenAddModal={(parent) => {
              setTargetParentForNewItem(parent);
              setShowNewBOMItemModal(true);
            }}
            onInitiateECO={handleInitiateECOForPart}
            onDeleteBOMItem={handleDeleteBOMItem}
          />
        )}

        {activeTab === 'diff' && (
          <RevisionDiffView
            product={selectedProduct}
            revisions={revisions}
            onOpenECO={(ecoNum) => {
              setActiveTab('eco');
            }}
          />
        )}

        {activeTab === 'eco' && (
          <ChangeOrdersView
            ecos={ecos}
            products={products}
            selectedProduct={selectedProduct}
            currentUser={currentUser}
            onUpdateECO={handleUpdateECO}
            onCreateECO={handleCreateECO}
            onSelectItem={(item) => setSelectedItemForDetail(item)}
          />
        )}

        {activeTab === 'suppliers' && (
          <SupplierPortalView
            suppliers={suppliers}
            rfqs={rfqs}
            products={products}
            selectedProduct={selectedProduct}
            isSupplierMode={isSupplierMode}
            onToggleSupplierMode={handleToggleSupplierMode}
            onUpdateRFQ={handleUpdateRFQ}
            onCreateRFQ={handleCreateRFQ}
            onSelectItem={(item) => setSelectedItemForDetail(item)}
          />
        )}

        {activeTab === 'items' && (
          <ItemMasterView
            products={products}
            onSelectItem={(item) => setSelectedItemForDetail(item)}
            onOpenWhereUsed={(item) => setSelectedItemForWhereUsed(item)}
            onInitiateECO={handleInitiateECOForPart}
            onOpenNewItemModal={() => {
              setTargetParentForNewItem(undefined);
              setShowNewBOMItemModal(true);
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-slate-900 text-white flex items-center justify-center font-bold text-[10px]">
              K
            </div>
            <span className="font-semibold text-slate-800">KitePLM</span>
            <span>·</span>
            <span>Modern Hardware Lifecycle Management for Mid-Market Manufacturers</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <span>ISO 9001 / AS9100 Ready</span>
            <span>·</span>
            <span>RoHS 3 & REACH SVHC Compliant</span>
            <span>·</span>
            <span>Single-Elevation Architecture</span>
          </div>
        </div>
      </footer>

      {/* Part Technical Detail Drawer */}
      <PartDetailDrawer
        item={selectedItemForDetail}
        onClose={() => setSelectedItemForDetail(null)}
        onOpenWhereUsed={(item) => setSelectedItemForWhereUsed(item)}
        onInitiateECO={handleInitiateECOForPart}
        onUpdateItemAML={handleUpdateItemAML}
      />

      {/* Where-Used Reverse Dependency Modal */}
      <WhereUsedModal
        item={selectedItemForWhereUsed}
        products={products}
        ecos={ecos}
        onClose={() => setSelectedItemForWhereUsed(null)}
        onNavigateToProduct={(prodId) => {
          setSelectedProductId(prodId);
          setActiveTab('bom');
        }}
        onOpenECO={(ecoId) => {
          setActiveTab('eco');
        }}
      />

      {/* New Product Assembly Modal */}
      {showNewProductModal && (
        <NewProductModal
          onClose={() => setShowNewProductModal(false)}
          onCreate={(newProd) => {
            setProducts([newProd, ...products]);
            setSelectedProductId(newProd.id);
            setShowNewProductModal(false);
          }}
        />
      )}

      {/* New BOM Item Modal */}
      {showNewBOMItemModal && (
        <NewBOMItemModal
          product={selectedProduct}
          parentItem={targetParentForNewItem}
          onClose={() => setShowNewBOMItemModal(false)}
          onAdd={handleAddBOMItem}
        />
      )}
    </div>
  );
}
