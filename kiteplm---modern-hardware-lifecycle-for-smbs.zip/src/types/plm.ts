export type LifecycleStage = 
  | 'Concept'
  | 'Prototype'
  | 'EVT'       // Engineering Validation Test
  | 'DVT'       // Design Validation Test
  | 'PVT'       // Production Validation Test
  | 'Production'
  | 'EOL';      // End of Life

export type PartCategory = 
  | 'Mechanical'
  | 'Electrical'
  | 'PCBA'
  | 'Electromechanical'
  | 'Optical'
  | 'Firmware'
  | 'Fasteners'
  | 'Packaging'
  | 'Raw Material';

export type SourcingType = 'Single Source' | 'Multi Source' | 'Sole Source' | 'Custom Tooling';

export type ComplianceStatus = 'RoHS & REACH Compliant' | 'RoHS Only' | 'Non-Compliant' | 'Pending Testing';

export type ECOStatus = 'Draft' | 'Technical Review' | 'CCB Review' | 'Approved' | 'Implemented' | 'Rejected';

export type ECOPriority = 'Low' | 'Standard' | 'Urgent' | 'Mandatory Recall';

export type Disposition = 'Use As-Is' | 'Rework Existing' | 'Scrap Existing' | 'Phase-in at Serial #';

export interface AMLVendor {
  vendorId: string;
  vendorName: string;
  mpn: string; // Manufacturer Part Number
  isPreferred: boolean;
  unitCost: number;
  leadTimeWeeks: number;
  moq: number; // Minimum Order Quantity
  packaging: string; // e.g. Tape & Reel, Bulk, Tray
  compliance: ComplianceStatus;
  notes?: string;
}

export interface BOMItem {
  id: string;
  partNumber: string; // e.g., ASM-1001, MEC-2041, ELE-3105
  name: string;
  revision: string; // e.g., 'A', 'B.1', 'C'
  description: string;
  category: PartCategory;
  quantity: number;
  unitOfMeasure: 'ea' | 'mm' | 'm' | 'g' | 'set';
  unitCost: number; // In USD
  leadTimeWeeks: number;
  lifecycle: LifecycleStage;
  sourcing: SourcingType;
  primarySupplier: string;
  primaryMpn: string;
  compliance: ComplianceStatus;
  amlList: AMLVendor[];
  parentId: string | null; // For hierarchical multi-level BOM
  level: number;
  children?: BOMItem[];
  cadFilename?: string;
  weightGrams?: number;
  notes?: string;
  hasDrawings?: boolean;
}

export interface ProductAssembly {
  id: string;
  sku: string;
  name: string;
  codeName: string;
  currentRevision: string;
  lifecycle: LifecycleStage;
  description: string;
  targetMarket: string;
  targetMSRP: number;
  estimatedAnnualVolume: number;
  bom: BOMItem[]; // Level 0 contains top-level or hierarchical tree
  createdDate: string;
  updatedDate: string;
}

export interface BOMRevisionSnapshot {
  id: string;
  productId: string;
  revision: string;
  releaseDate: string;
  releasedBy: string;
  ecoReference?: string;
  description: string;
  items: BOMItem[];
  totalCost: number;
  totalWeightGrams: number;
}

export interface ECOAffectedItem {
  partId: string;
  partNumber: string;
  name: string;
  fromRevision: string;
  toRevision: string;
  disposition: Disposition;
  quantityInStock: number;
  scrapCost: number;
  notes: string;
}

export interface ECOSignoff {
  role: 'Lead Mechanical' | 'Lead Electrical' | 'Supply Chain' | 'Quality & Compliance' | 'VP of Engineering';
  assigneeName: string;
  assigneeTitle: string;
  signed: boolean;
  signedDate?: string;
  comments?: string;
}

export interface EngineeringChangeOrder {
  id: string;
  ecoNumber: string; // e.g. ECO-2026-088
  title: string;
  productId: string;
  productName: string;
  originator: string;
  originatorEmail: string;
  status: ECOStatus;
  priority: ECOPriority;
  changeType: 'Cost Reduction' | 'Reliability / Defect' | 'Obsolescence' | 'Feature Enhancement' | 'Regulatory';
  createdDate: string;
  targetImplementationDate: string;
  reasonForChange: string;
  descriptionOfChange: string;
  affectedItems: ECOAffectedItem[];
  totalScrapCost: number;
  netUnitCostImpact: number; // e.g. -2.40 (saves $2.40 per unit)
  signoffs: ECOSignoff[];
}

export interface SupplierRFQ {
  id: string;
  rfqNumber: string;
  supplierId: string;
  supplierName: string;
  supplierContact: string;
  partId: string;
  partNumber: string;
  partName: string;
  status: 'Open' | 'Quoted' | 'Awarded' | 'Declined';
  requestedQty: number;
  targetPrice: number;
  quotedPrice?: number;
  quotedLeadTimeWeeks?: number;
  quoteNotes?: string;
  createdDate: string;
  quoteValidUntil?: string;
  tierPricing?: { qty: number; price: number }[];
}

export interface SupplierProfile {
  id: string;
  name: string;
  category: 'Contract Manufacturer (CM)' | 'PCB Fabrication' | 'CNC & Sheet Metal' | 'Electronic Distributor' | 'Fasteners & Hardware' | 'Sensors & Optics';
  rating: number; // 1-5 stars
  location: string;
  contactEmail: string;
  ndaStatus: 'Executed' | 'Pending' | 'Expired';
  isoCertifications: string[];
  assignedPartsCount: number;
  averageLeadTimeWeeks: number;
}
