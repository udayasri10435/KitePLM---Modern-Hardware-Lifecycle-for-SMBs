import { ProductAssembly, BOMRevisionSnapshot, EngineeringChangeOrder, SupplierProfile, SupplierRFQ, BOMItem } from '../types/plm';

export const initialSuppliers: SupplierProfile[] = [
  {
    id: 'SUP-01',
    name: 'Apex Precision CNC',
    category: 'CNC & Sheet Metal',
    rating: 4.9,
    location: 'Munich, Germany & San Jose, CA',
    contactEmail: 'engineering@apex-precision.de',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001:2015', 'AS9100D'],
    assignedPartsCount: 7,
    averageLeadTimeWeeks: 3.2
  },
  {
    id: 'SUP-02',
    name: 'Novatronics PCBA Solutions',
    category: 'Contract Manufacturer (CM)',
    rating: 4.8,
    location: 'Penang, Malaysia & Austin, TX',
    contactEmail: 'npi-quotes@novatronics-mfg.com',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001:2015', 'ISO 13485 (Medical)', 'IPC-A-610 Class 3'],
    assignedPartsCount: 12,
    averageLeadTimeWeeks: 4.5
  },
  {
    id: 'SUP-03',
    name: 'Arrow Electronics Global',
    category: 'Electronic Distributor',
    rating: 4.7,
    location: 'Centennial, CO (Global Warehouses)',
    contactEmail: 'arrow-enterprise@arrow.com',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001', 'ANSI/ESD S20.20'],
    assignedPartsCount: 22,
    averageLeadTimeWeeks: 2.1
  },
  {
    id: 'SUP-04',
    name: 'Sunstone QuickTurn PCB',
    category: 'PCB Fabrication',
    rating: 4.9,
    location: 'Mulino, OR',
    contactEmail: 'support@sunstone.com',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001:2015', 'ITAR Registered'],
    assignedPartsCount: 4,
    averageLeadTimeWeeks: 1.8
  },
  {
    id: 'SUP-05',
    name: 'TitanFast Precision Hardware',
    category: 'Fasteners & Hardware',
    rating: 4.8,
    location: 'Taichung, Taiwan',
    contactEmail: 'sales@titanfast-tw.com',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001', 'RoHS / REACH Certified'],
    assignedPartsCount: 8,
    averageLeadTimeWeeks: 2.5
  },
  {
    id: 'SUP-06',
    name: 'Sensirion & Optics Consortium',
    category: 'Sensors & Optics',
    rating: 4.6,
    location: 'Stäfa, Switzerland',
    contactEmail: 'b2b-optics@sensirion-partners.com',
    ndaStatus: 'Executed',
    isoCertifications: ['ISO 9001', 'IATF 16949'],
    assignedPartsCount: 5,
    averageLeadTimeWeeks: 6.0
  }
];

export const initialProducts: ProductAssembly[] = [
  {
    id: 'PRD-1001',
    sku: 'APX-4-ENT',
    name: 'AeroPulse-X4 Industrial Inspection Drone',
    codeName: 'SkyHawk',
    currentRevision: 'B',
    lifecycle: 'DVT',
    description: 'Autonomous industrial quadcopter engineered for bridge, pipeline, and offshore utility inspections featuring 360° LiDAR and dual 4K/thermal optical payload.',
    targetMarket: 'Civil Infrastructure & Energy',
    targetMSRP: 8400,
    estimatedAnnualVolume: 2500,
    createdDate: '2025-11-12',
    updatedDate: '2026-09-24',
    bom: [
      {
        id: 'BOM-1000',
        partNumber: 'ASM-1000',
        name: 'AeroPulse-X4 Complete Unmanned System',
        revision: 'B',
        description: 'Complete assembled flight vehicle ready for factory acceptance calibration',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 1348.60,
        leadTimeWeeks: 8,
        lifecycle: 'DVT',
        sourcing: 'Custom Tooling',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'KITE-APX4-SYS-B',
        compliance: 'RoHS & REACH Compliant',
        amlList: [
          {
            vendorId: 'SUP-02',
            vendorName: 'Novatronics PCBA Solutions',
            mpn: 'KITE-APX4-SYS-B',
            isPreferred: true,
            unitCost: 1348.60,
            leadTimeWeeks: 8,
            moq: 50,
            packaging: 'Custom Anti-Static Crate',
            compliance: 'RoHS & REACH Compliant'
          }
        ],
        parentId: null,
        level: 0,
        weightGrams: 2850,
        hasDrawings: true,
        children: [
          // Sub-assembly 1: Airframe
          {
            id: 'BOM-1100',
            partNumber: 'ASM-1100',
            name: 'Carbon Composite Airframe & Arm Structure',
            revision: 'B',
            description: 'Ultra-rigid 3K twill carbon fiber chassis with quick-fold arm locking mechanisms',
            category: 'Mechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 245.50,
            leadTimeWeeks: 4,
            lifecycle: 'DVT',
            sourcing: 'Multi Source',
            primarySupplier: 'Apex Precision CNC',
            primaryMpn: 'APX-FRM-002B',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-01',
                vendorName: 'Apex Precision CNC',
                mpn: 'APX-FRM-002B',
                isPreferred: true,
                unitCost: 245.50,
                leadTimeWeeks: 4,
                moq: 100,
                packaging: 'Custom Molded Tray',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-1000',
            level: 1,
            weightGrams: 720,
            hasDrawings: true,
            children: [
              {
                id: 'BOM-1110',
                partNumber: 'MEC-1110',
                name: 'Carbon Fiber Unibody Top/Bottom Deck Plates',
                revision: 'B',
                description: '2.5mm compression-molded 3K carbon twill with matte anti-glare finish',
                category: 'Mechanical',
                quantity: 2,
                unitOfMeasure: 'ea',
                unitCost: 38.00,
                leadTimeWeeks: 3,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'Apex Precision CNC',
                primaryMpn: 'CFP-25-3K-M',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-01',
                    vendorName: 'Apex Precision CNC',
                    mpn: 'CFP-25-3K-M',
                    isPreferred: true,
                    unitCost: 38.00,
                    leadTimeWeeks: 3,
                    moq: 200,
                    packaging: 'Bubble Sleeved',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1100',
                level: 2,
                weightGrams: 210,
                hasDrawings: true
              },
              {
                id: 'BOM-1120',
                partNumber: 'MEC-1120',
                name: 'Folding Tubular Motor Arm (22mm OD x 320mm)',
                revision: 'B',
                description: 'Roll-wrapped carbon fiber tube with integrated 7075-T6 aluminum hinge clamp',
                category: 'Mechanical',
                quantity: 4,
                unitOfMeasure: 'ea',
                unitCost: 28.50,
                leadTimeWeeks: 4,
                lifecycle: 'DVT',
                sourcing: 'Multi Source',
                primarySupplier: 'Apex Precision CNC',
                primaryMpn: 'ARM-22-320-AL7075',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-01',
                    vendorName: 'Apex Precision CNC',
                    mpn: 'ARM-22-320-AL7075',
                    isPreferred: true,
                    unitCost: 28.50,
                    leadTimeWeeks: 4,
                    moq: 400,
                    packaging: 'Bulk carton',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1100',
                level: 2,
                weightGrams: 95,
                hasDrawings: true
              },
              {
                id: 'BOM-1130',
                partNumber: 'FAS-1130',
                name: 'M3 x 8mm Grade 5 Titanium Button Head Torx Screws',
                revision: 'A',
                description: 'Ti-6Al-4V aerospace grade fasteners with blue threadlock pre-applied',
                category: 'Fasteners',
                quantity: 24,
                unitOfMeasure: 'ea',
                unitCost: 0.85,
                leadTimeWeeks: 2,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'TitanFast Precision Hardware',
                primaryMpn: 'TI-M3-8-BTN-TRX',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-05',
                    vendorName: 'TitanFast Precision Hardware',
                    mpn: 'TI-M3-8-BTN-TRX',
                    isPreferred: true,
                    unitCost: 0.85,
                    leadTimeWeeks: 2,
                    moq: 5000,
                    packaging: 'Bag of 500',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1100',
                level: 2,
                weightGrams: 1.2,
                hasDrawings: false
              },
              {
                id: 'BOM-1140',
                partNumber: 'MEC-1140',
                name: 'Fluoro-silicone Vibration Isolator Dampers',
                revision: 'A',
                description: 'Shore 40A tuned frequency damping bobbins for payload decoupling',
                category: 'Mechanical',
                quantity: 8,
                unitOfMeasure: 'ea',
                unitCost: 1.45,
                leadTimeWeeks: 2,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'TitanFast Precision Hardware',
                primaryMpn: 'ISO-SIL-40A-08',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-05',
                    vendorName: 'TitanFast Precision Hardware',
                    mpn: 'ISO-SIL-40A-08',
                    isPreferred: true,
                    unitCost: 1.45,
                    leadTimeWeeks: 2,
                    moq: 1000,
                    packaging: 'Bags of 100',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1100',
                level: 2,
                weightGrams: 4.5,
                hasDrawings: true
              }
            ]
          },

          // Sub-assembly 2: Avionics
          {
            id: 'BOM-1200',
            partNumber: 'ASM-1200',
            name: 'Avionics, Flight Core & Navigation Module',
            revision: 'B',
            description: 'Redundant triple-IMU flight computer with RTK GNSS and encrypted datalink',
            category: 'PCBA',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 312.40,
            leadTimeWeeks: 6,
            lifecycle: 'DVT',
            sourcing: 'Custom Tooling',
            primarySupplier: 'Novatronics PCBA Solutions',
            primaryMpn: 'NVT-APX-AVN-B2',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-02',
                vendorName: 'Novatronics PCBA Solutions',
                mpn: 'NVT-APX-AVN-B2',
                isPreferred: true,
                unitCost: 312.40,
                leadTimeWeeks: 6,
                moq: 100,
                packaging: 'ESD Shielded Bag',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-1000',
            level: 1,
            weightGrams: 145,
            hasDrawings: true,
            children: [
              {
                id: 'BOM-1210',
                partNumber: 'PCB-1210',
                name: 'Flight Controller 8-Layer ENIG Rigid Board',
                revision: 'B',
                description: 'High Tg FR4 8-layer impedance-controlled board with buried microvias',
                category: 'PCBA',
                quantity: 1,
                unitOfMeasure: 'ea',
                unitCost: 18.50,
                leadTimeWeeks: 2,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'Sunstone QuickTurn PCB',
                primaryMpn: 'SST-8L-FR4-ENIG-B',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-04',
                    vendorName: 'Sunstone QuickTurn PCB',
                    mpn: 'SST-8L-FR4-ENIG-B',
                    isPreferred: true,
                    unitCost: 18.50,
                    leadTimeWeeks: 2,
                    moq: 250,
                    packaging: 'Vacuum Sealed Panels',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1200',
                level: 2,
                weightGrams: 32,
                hasDrawings: true
              },
              {
                id: 'BOM-1220',
                partNumber: 'ELE-1220',
                name: 'Dual Core Cortex-M7 MCU 480MHz 2MB Flash',
                revision: 'A',
                description: 'STMicroelectronics STM32H743IIT6 LQFP-176',
                category: 'Electrical',
                quantity: 2,
                unitOfMeasure: 'ea',
                unitCost: 19.80,
                leadTimeWeeks: 14,
                lifecycle: 'Production',
                sourcing: 'Single Source',
                primarySupplier: 'Arrow Electronics Global',
                primaryMpn: 'STM32H743IIT6',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-03',
                    vendorName: 'Arrow Electronics Global',
                    mpn: 'STM32H743IIT6',
                    isPreferred: true,
                    unitCost: 19.80,
                    leadTimeWeeks: 14,
                    moq: 360,
                    packaging: 'Tray of 60',
                    compliance: 'RoHS & REACH Compliant',
                    notes: 'Single source alert: monitor ST allocation closely'
                  }
                ],
                parentId: 'BOM-1200',
                level: 2,
                weightGrams: 5.2,
                hasDrawings: false
              },
              {
                id: 'BOM-1230',
                partNumber: 'ELE-1230',
                name: 'High Precision Multi-Band RTK GNSS Receiver Module',
                revision: 'B',
                description: 'u-blox ZED-F9P L1/L2 multi-constellation centimeter-level positioning',
                category: 'Electrical',
                quantity: 1,
                unitOfMeasure: 'ea',
                unitCost: 142.00,
                leadTimeWeeks: 8,
                lifecycle: 'Production',
                sourcing: 'Sole Source',
                primarySupplier: 'Arrow Electronics Global',
                primaryMpn: 'ZED-F9P-04B',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-03',
                    vendorName: 'Arrow Electronics Global',
                    mpn: 'ZED-F9P-04B',
                    isPreferred: true,
                    unitCost: 142.00,
                    leadTimeWeeks: 8,
                    moq: 50,
                    packaging: 'Tape & Reel 250',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1200',
                level: 2,
                weightGrams: 8.4,
                hasDrawings: false
              },
              {
                id: 'BOM-1240',
                partNumber: 'ELE-1240',
                name: 'Industrial 6-Axis Low-Noise IMU with Accel & Gyro',
                revision: 'A',
                description: 'TDK InvenSense ICM-42688-P ultra-low noise motion sensor LGA-14',
                category: 'Electrical',
                quantity: 3,
                unitOfMeasure: 'ea',
                unitCost: 6.20,
                leadTimeWeeks: 4,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'Arrow Electronics Global',
                primaryMpn: 'ICM-42688-P',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-03',
                    vendorName: 'Arrow Electronics Global',
                    mpn: 'ICM-42688-P',
                    isPreferred: true,
                    unitCost: 6.20,
                    leadTimeWeeks: 4,
                    moq: 1000,
                    packaging: 'Tape & Reel',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1200',
                level: 2,
                weightGrams: 0.1,
                hasDrawings: false
              }
            ]
          },

          // Sub-assembly 3: Propulsion
          {
            id: 'BOM-1300',
            partNumber: 'ASM-1300',
            name: 'High-Efficiency Propulsion & Power Train System',
            revision: 'B',
            description: 'Four 4006 380KV brushless motors matched with 60A FOC ESC and folding carbon props',
            category: 'Electromechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 382.70,
            leadTimeWeeks: 5,
            lifecycle: 'DVT',
            sourcing: 'Multi Source',
            primarySupplier: 'Novatronics PCBA Solutions',
            primaryMpn: 'APX-PROP-60A-B',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-02',
                vendorName: 'Novatronics PCBA Solutions',
                mpn: 'APX-PROP-60A-B',
                isPreferred: true,
                unitCost: 382.70,
                leadTimeWeeks: 5,
                moq: 100,
                packaging: 'Bulk carton',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-1000',
            level: 1,
            weightGrams: 890,
            hasDrawings: true,
            children: [
              {
                id: 'BOM-1310',
                partNumber: 'MOT-1310',
                name: 'Brushless Outrunner Motor 4006 380KV IP55',
                revision: 'B',
                description: 'Custom wound low-vibration stator with N48H high temp neodymium magnets',
                category: 'Electromechanical',
                quantity: 4,
                unitOfMeasure: 'ea',
                unitCost: 54.00,
                leadTimeWeeks: 5,
                lifecycle: 'DVT',
                sourcing: 'Multi Source',
                primarySupplier: 'Novatronics PCBA Solutions',
                primaryMpn: 'BLDC-4006-380KV-IP55',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-02',
                    vendorName: 'Novatronics PCBA Solutions',
                    mpn: 'BLDC-4006-380KV-IP55',
                    isPreferred: true,
                    unitCost: 54.00,
                    leadTimeWeeks: 5,
                    moq: 200,
                    packaging: 'Foam Tray',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1300',
                level: 2,
                weightGrams: 115,
                hasDrawings: true
              },
              {
                id: 'BOM-1320',
                partNumber: 'ELE-1320',
                name: '4-in-1 60A FOC Motor Driver & Power Distribution PCBA',
                revision: 'B',
                description: 'CAN-bus telemetry FOC motor controller with regenerative active braking',
                category: 'PCBA',
                quantity: 1,
                unitOfMeasure: 'ea',
                unitCost: 98.70,
                leadTimeWeeks: 4,
                lifecycle: 'DVT',
                sourcing: 'Multi Source',
                primarySupplier: 'Novatronics PCBA Solutions',
                primaryMpn: 'NVT-ESC-4IN1-60A',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-02',
                    vendorName: 'Novatronics PCBA Solutions',
                    mpn: 'NVT-ESC-4IN1-60A',
                    isPreferred: true,
                    unitCost: 98.70,
                    leadTimeWeeks: 4,
                    moq: 200,
                    packaging: 'ESD Bag',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1300',
                level: 2,
                weightGrams: 75,
                hasDrawings: true
              },
              {
                id: 'BOM-1330',
                partNumber: 'MEC-1330',
                name: '15.5 x 5.2 Inch Folding Carbon Fiber Propeller Pair',
                revision: 'A',
                description: 'Aerodynamic winglet tipped folding blades dynamically balanced to <0.02g',
                category: 'Mechanical',
                quantity: 2,
                unitOfMeasure: 'set',
                unitCost: 34.00,
                leadTimeWeeks: 3,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'Apex Precision CNC',
                primaryMpn: 'PROP-155-CF-PAIR',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-01',
                    vendorName: 'Apex Precision CNC',
                    mpn: 'PROP-155-CF-PAIR',
                    isPreferred: true,
                    unitCost: 34.00,
                    leadTimeWeeks: 3,
                    moq: 500,
                    packaging: 'Matched Pair Pouch',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1300',
                level: 2,
                weightGrams: 52,
                hasDrawings: true
              }
            ]
          },

          // Sub-assembly 4: LiDAR & Optical Gimbal
          {
            id: 'BOM-1400',
            partNumber: 'ASM-1400',
            name: '3-Axis Direct Drive Stabilized Sensor Gimbal',
            revision: 'B',
            description: '360° LiDAR payload pod with optical high-res inspection camera',
            category: 'Optical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 408.00,
            leadTimeWeeks: 6,
            lifecycle: 'DVT',
            sourcing: 'Custom Tooling',
            primarySupplier: 'Sensirion & Optics Consortium',
            primaryMpn: 'OPT-GMB-360-B',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-06',
                vendorName: 'Sensirion & Optics Consortium',
                mpn: 'OPT-GMB-360-B',
                isPreferred: true,
                unitCost: 408.00,
                leadTimeWeeks: 6,
                moq: 50,
                packaging: 'Calibrated Optics Enclosure',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-1000',
            level: 1,
            weightGrams: 640,
            hasDrawings: true,
            children: [
              {
                id: 'BOM-1410',
                partNumber: 'OPT-1410',
                name: 'Solid-State Mid-Range LiDAR Sensor Core',
                revision: 'B',
                description: '200m range 905nm non-repetitive scanning beam sensor module',
                category: 'Optical',
                quantity: 1,
                unitOfMeasure: 'ea',
                unitCost: 295.00,
                leadTimeWeeks: 6,
                lifecycle: 'DVT',
                sourcing: 'Sole Source',
                primarySupplier: 'Sensirion & Optics Consortium',
                primaryMpn: 'LVX-MID-360-OEM',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-06',
                    vendorName: 'Sensirion & Optics Consortium',
                    mpn: 'LVX-MID-360-OEM',
                    isPreferred: true,
                    unitCost: 295.00,
                    leadTimeWeeks: 6,
                    moq: 50,
                    packaging: 'Anti-Static Molded Case',
                    compliance: 'RoHS & REACH Compliant',
                    notes: 'Sole source partner component'
                  }
                ],
                parentId: 'BOM-1400',
                level: 2,
                weightGrams: 265,
                hasDrawings: true
              },
              {
                id: 'BOM-1420',
                partNumber: 'MEC-1420',
                name: 'CNC 6061-T6 Aluminum Gimbal Yoke & Housing',
                revision: 'B',
                description: '5-axis milled lightweight aerospace bracket with hard anodized black coat',
                category: 'Mechanical',
                quantity: 1,
                unitOfMeasure: 'ea',
                unitCost: 68.00,
                leadTimeWeeks: 3,
                lifecycle: 'DVT',
                sourcing: 'Multi Source',
                primarySupplier: 'Apex Precision CNC',
                primaryMpn: 'GMB-YKE-6061-BLK',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-01',
                    vendorName: 'Apex Precision CNC',
                    mpn: 'GMB-YKE-6061-BLK',
                    isPreferred: true,
                    unitCost: 68.00,
                    leadTimeWeeks: 3,
                    moq: 150,
                    packaging: 'Individual foam wrap',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1400',
                level: 2,
                weightGrams: 140,
                hasDrawings: true
              },
              {
                id: 'BOM-1430',
                partNumber: 'MOT-1430',
                name: 'Direct Drive Hollow-Shaft Gimbal Motor with Encoder',
                revision: 'A',
                description: 'Zero backlash brushless gimbal motor with magnetic 14-bit absolute encoder',
                category: 'Electromechanical',
                quantity: 3,
                unitOfMeasure: 'ea',
                unitCost: 15.00,
                leadTimeWeeks: 4,
                lifecycle: 'Production',
                sourcing: 'Multi Source',
                primarySupplier: 'Novatronics PCBA Solutions',
                primaryMpn: 'GMB-MOT-2804-ENC',
                compliance: 'RoHS & REACH Compliant',
                amlList: [
                  {
                    vendorId: 'SUP-02',
                    vendorName: 'Novatronics PCBA Solutions',
                    mpn: 'GMB-MOT-2804-ENC',
                    isPreferred: true,
                    unitCost: 15.00,
                    leadTimeWeeks: 4,
                    moq: 300,
                    packaging: 'Tray of 50',
                    compliance: 'RoHS & REACH Compliant'
                  }
                ],
                parentId: 'BOM-1400',
                level: 2,
                weightGrams: 45,
                hasDrawings: true
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'PRD-2002',
    sku: 'VLS-EDGE-IP67',
    name: 'VeloSense-Edge IP67 Industrial IoT Gateway',
    codeName: 'IronClad',
    currentRevision: 'C',
    lifecycle: 'PVT',
    description: 'Ruggedized edge computing gateway featuring dual Ethernet, LTE-M/NB-IoT, LoRaWAN concentrator, and wide-temp battery backup for remote oilfield telemetry.',
    targetMarket: 'Industrial Automation & Oil/Gas',
    targetMSRP: 1850,
    estimatedAnnualVolume: 8000,
    createdDate: '2025-08-04',
    updatedDate: '2026-09-18',
    bom: [
      {
        id: 'BOM-2000',
        partNumber: 'ASM-2000',
        name: 'VeloSense Edge Gateway Top Assembly',
        revision: 'C',
        description: 'Sealed IP67 industrial gateway enclosure with internal compute stack',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 342.15,
        leadTimeWeeks: 6,
        lifecycle: 'PVT',
        sourcing: 'Custom Tooling',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'VLS-EDGE-ASM-03',
        compliance: 'RoHS & REACH Compliant',
        amlList: [
          {
            vendorId: 'SUP-02',
            vendorName: 'Novatronics PCBA Solutions',
            mpn: 'VLS-EDGE-ASM-03',
            isPreferred: true,
            unitCost: 342.15,
            leadTimeWeeks: 6,
            moq: 200,
            packaging: 'Retail Master Carton',
            compliance: 'RoHS & REACH Compliant'
          }
        ],
        parentId: null,
        level: 0,
        weightGrams: 1420,
        hasDrawings: true,
        children: [
          {
            id: 'BOM-2100',
            partNumber: 'MEC-2100',
            name: 'CNC 6063 Aluminum Extruded Chassis Body',
            revision: 'C',
            description: 'Heavy finned heat dissipation chassis with black hard anodize MIL-A-8625',
            category: 'Mechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 46.50,
            leadTimeWeeks: 3,
            lifecycle: 'Production',
            sourcing: 'Multi Source',
            primarySupplier: 'Apex Precision CNC',
            primaryMpn: 'CHS-6063-FIN-03C',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-01',
                vendorName: 'Apex Precision CNC',
                mpn: 'CHS-6063-FIN-03C',
                isPreferred: true,
                unitCost: 46.50,
                leadTimeWeeks: 3,
                moq: 500,
                packaging: 'Egg-crate cardboard',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-2000',
            level: 1,
            weightGrams: 820,
            hasDrawings: true
          },
          {
            id: 'BOM-2200',
            partNumber: 'PCB-2200',
            name: 'NXP i.MX8M Plus Quad-Core Gateway PCBA',
            revision: 'C',
            description: 'Mainboard with 4GB LPDDR4, 32GB eMMC, Dual GbE, Isolated CAN & RS485',
            category: 'PCBA',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 188.00,
            leadTimeWeeks: 6,
            lifecycle: 'PVT',
            sourcing: 'Custom Tooling',
            primarySupplier: 'Novatronics PCBA Solutions',
            primaryMpn: 'NVT-IMX8M-GW-C',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-02',
                vendorName: 'Novatronics PCBA Solutions',
                mpn: 'NVT-IMX8M-GW-C',
                isPreferred: true,
                unitCost: 188.00,
                leadTimeWeeks: 6,
                moq: 250,
                packaging: 'ESD Bag with Desiccant',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-2000',
            level: 1,
            weightGrams: 110,
            hasDrawings: true
          },
          {
            id: 'BOM-2300',
            partNumber: 'ELE-2300',
            name: 'Quectel BG95-M3 Multi-Mode LTE Cat M1/NB2 Module',
            revision: 'A',
            description: 'Global IoT cellular modem with integrated GNSS and eSIM provisioning',
            category: 'Electrical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 32.50,
            leadTimeWeeks: 4,
            lifecycle: 'Production',
            sourcing: 'Multi Source',
            primarySupplier: 'Arrow Electronics Global',
            primaryMpn: 'BG95-M3-MINIPCIE',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-03',
                vendorName: 'Arrow Electronics Global',
                mpn: 'BG95-M3-MINIPCIE',
                isPreferred: true,
                unitCost: 32.50,
                leadTimeWeeks: 4,
                moq: 100,
                packaging: 'Tray of 50',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-2000',
            level: 1,
            weightGrams: 9.8,
            hasDrawings: false
          },
          {
            id: 'BOM-2400',
            partNumber: 'BAT-2400',
            name: 'LiFePO4 3.2V 3200mAh High-Temperature Backup Cell',
            revision: 'A',
            description: 'UL1642 certified -40°C to +85°C rated power outage ride-through cell',
            category: 'Electrical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 18.20,
            leadTimeWeeks: 5,
            lifecycle: 'Production',
            sourcing: 'Single Source',
            primarySupplier: 'Arrow Electronics Global',
            primaryMpn: 'LFP-18650-3200-HT',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-03',
                vendorName: 'Arrow Electronics Global',
                mpn: 'LFP-18650-3200-HT',
                isPreferred: true,
                unitCost: 18.20,
                leadTimeWeeks: 5,
                moq: 500,
                packaging: 'UN38.3 Certified Carton',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-2000',
            level: 1,
            weightGrams: 48,
            hasDrawings: false
          },
          {
            id: 'BOM-2500',
            partNumber: 'MEC-2500',
            name: 'Molded Fluorosilicone IP67 Perimeter Seal Gasket',
            revision: 'C',
            description: 'Custom molded continuous gasket rated IP67/IP69K washdown resistance',
            category: 'Mechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 3.40,
            leadTimeWeeks: 2,
            lifecycle: 'Production',
            sourcing: 'Multi Source',
            primarySupplier: 'TitanFast Precision Hardware',
            primaryMpn: 'GSK-IP67-VLS-03',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-05',
                vendorName: 'TitanFast Precision Hardware',
                mpn: 'GSK-IP67-VLS-03',
                isPreferred: true,
                unitCost: 3.40,
                leadTimeWeeks: 2,
                moq: 2000,
                packaging: 'Bag of 200',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-2000',
            level: 1,
            weightGrams: 14,
            hasDrawings: true
          }
        ]
      }
    ]
  },
  {
    id: 'PRD-3003',
    sku: 'NG6-JNT-MED',
    name: 'NeuroGlide-6X Medical Robotic Arm Articulator',
    codeName: 'ApexJoint',
    currentRevision: 'A',
    lifecycle: 'EVT',
    description: 'Precision surgical articulation actuator joint featuring dual optical absolute encoders, Zero-Backlash strain wave reduction, and ISO 13485 sterile cleanability.',
    targetMarket: 'Minimally Invasive Robotic Surgery',
    targetMSRP: 14500,
    estimatedAnnualVolume: 600,
    createdDate: '2026-01-15',
    updatedDate: '2026-09-22',
    bom: [
      {
        id: 'BOM-3000',
        partNumber: 'ASM-3000',
        name: 'NeuroGlide Joint Actuator Module',
        revision: 'A',
        description: 'Complete robotic joint actuator sub-assembly with titanium sterile housing',
        category: 'Electromechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 2840.00,
        leadTimeWeeks: 12,
        lifecycle: 'EVT',
        sourcing: 'Custom Tooling',
        primarySupplier: 'Apex Precision CNC',
        primaryMpn: 'NG6-ACT-ASM-01A',
        compliance: 'RoHS & REACH Compliant',
        amlList: [
          {
            vendorId: 'SUP-01',
            vendorName: 'Apex Precision CNC',
            mpn: 'NG6-ACT-ASM-01A',
            isPreferred: true,
            unitCost: 2840.00,
            leadTimeWeeks: 12,
            moq: 20,
            packaging: 'Cleanroom Class 1000 Pack',
            compliance: 'RoHS & REACH Compliant'
          }
        ],
        parentId: null,
        level: 0,
        weightGrams: 980,
        hasDrawings: true,
        children: [
          {
            id: 'BOM-3100',
            partNumber: 'MEC-3100',
            name: 'Harmonic Drive Strain Wave Reducer (Ratio 100:1)',
            revision: 'A',
            description: 'Zero-backlash hollow shaft flexspline precision reduction gear set',
            category: 'Mechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 1150.00,
            leadTimeWeeks: 16,
            lifecycle: 'EVT',
            sourcing: 'Sole Source',
            primarySupplier: 'Apex Precision CNC',
            primaryMpn: 'HD-CSG-17-100-2UH',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-01',
                vendorName: 'Apex Precision CNC',
                mpn: 'HD-CSG-17-100-2UH',
                isPreferred: true,
                unitCost: 1150.00,
                leadTimeWeeks: 16,
                moq: 25,
                packaging: 'Sealed nitrogen pouch',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-3000',
            level: 1,
            weightGrams: 420,
            hasDrawings: true
          },
          {
            id: 'BOM-3200',
            partNumber: 'MOT-3200',
            name: 'Frameless Brushless Torque Motor Stator & Rotor Pair',
            revision: 'A',
            description: 'Ultra-high torque density slotless motor for ripple-free surgical motion',
            category: 'Electromechanical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 680.00,
            leadTimeWeeks: 10,
            lifecycle: 'EVT',
            sourcing: 'Single Source',
            primarySupplier: 'Apex Precision CNC',
            primaryMpn: 'KBM-14H01-A',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-01',
                vendorName: 'Apex Precision CNC',
                mpn: 'KBM-14H01-A',
                isPreferred: true,
                unitCost: 680.00,
                leadTimeWeeks: 10,
                moq: 30,
                packaging: 'Magnetic keeper ring box',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-3000',
            level: 1,
            weightGrams: 280,
            hasDrawings: true
          },
          {
            id: 'BOM-3300',
            partNumber: 'SEN-3300',
            name: 'Dual 19-Bit Optical Absolute Hollow-Shaft Rotary Encoder',
            revision: 'A',
            description: 'BiSS-C protocol position feedback with 524,288 counts per revolution resolution',
            category: 'Optical',
            quantity: 1,
            unitOfMeasure: 'ea',
            unitCost: 490.00,
            leadTimeWeeks: 8,
            lifecycle: 'EVT',
            sourcing: 'Single Source',
            primarySupplier: 'Sensirion & Optics Consortium',
            primaryMpn: 'ENC-BISS-19BIT-HS',
            compliance: 'RoHS & REACH Compliant',
            amlList: [
              {
                vendorId: 'SUP-06',
                vendorName: 'Sensirion & Optics Consortium',
                mpn: 'ENC-BISS-19BIT-HS',
                isPreferred: true,
                unitCost: 490.00,
                leadTimeWeeks: 8,
                moq: 20,
                packaging: 'Precision optical container',
                compliance: 'RoHS & REACH Compliant'
              }
            ],
            parentId: 'BOM-3000',
            level: 1,
            weightGrams: 65,
            hasDrawings: true
          }
        ]
      }
    ]
  }
];

export const initialRevisions: BOMRevisionSnapshot[] = [
  {
    id: 'REV-APX-A',
    productId: 'PRD-1001',
    revision: 'A',
    releaseDate: '2025-11-20',
    releasedBy: 'Sarah Chen (Lead Systems Eng)',
    ecoReference: 'ECO-2025-012',
    description: 'Initial Engineering Validation (EVT) Baseline Release with CNC Aluminum motor mounts and discrete 30A motor ESCs.',
    totalCost: 1420.80,
    totalWeightGrams: 2935,
    items: [
      {
        id: 'REV-A-01',
        partNumber: 'ASM-1000',
        name: 'AeroPulse-X4 Complete Unmanned System',
        revision: 'A',
        description: 'Complete assembled flight vehicle ready for factory acceptance calibration',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 1420.80,
        leadTimeWeeks: 9,
        lifecycle: 'EVT',
        sourcing: 'Custom Tooling',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'KITE-APX4-SYS-A',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: null,
        level: 0,
        weightGrams: 2935
      },
      {
        id: 'REV-A-02',
        partNumber: 'ASM-1100',
        name: 'Carbon Composite Airframe & Arm Structure',
        revision: 'A',
        description: 'Heavy aluminum clamped tubular arms',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 285.00,
        leadTimeWeeks: 5,
        lifecycle: 'EVT',
        sourcing: 'Multi Source',
        primarySupplier: 'Apex Precision CNC',
        primaryMpn: 'APX-FRM-001A',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-A-01',
        level: 1,
        weightGrams: 805
      },
      {
        id: 'REV-A-03',
        partNumber: 'FAS-1130',
        name: 'M3 x 8mm Stainless Steel Button Head Screws',
        revision: 'A',
        description: 'Standard 304 Stainless steel fasteners',
        category: 'Fasteners',
        quantity: 24,
        unitOfMeasure: 'ea',
        unitCost: 0.15,
        leadTimeWeeks: 1,
        lifecycle: 'Production',
        sourcing: 'Multi Source',
        primarySupplier: 'TitanFast Precision Hardware',
        primaryMpn: 'SS-M3-8-BTN',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-A-02',
        level: 2,
        weightGrams: 3.2
      },
      {
        id: 'REV-A-04',
        partNumber: 'ELE-1320',
        name: 'Discrete 4-Channel 35A BLDC ESC Drivers',
        revision: 'A',
        description: 'Legacy 4 separate ESC modules with excessive wire loom',
        category: 'PCBA',
        quantity: 4,
        unitOfMeasure: 'ea',
        unitCost: 31.00,
        leadTimeWeeks: 6,
        lifecycle: 'EVT',
        sourcing: 'Multi Source',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'ESC-35A-DISC-01',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-A-01',
        level: 2,
        weightGrams: 140
      },
      {
        id: 'REV-A-05',
        partNumber: 'OPT-1410',
        name: 'Legacy 2D Laser Rangefinder Scanner Core',
        revision: 'A',
        description: 'Single-plane 25m scanner used for initial collision avoidance prototyping',
        category: 'Optical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 215.00,
        leadTimeWeeks: 4,
        lifecycle: 'EVT',
        sourcing: 'Single Source',
        primarySupplier: 'Sensirion & Optics Consortium',
        primaryMpn: 'RPLIDAR-S2-OEM',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-A-01',
        level: 2,
        weightGrams: 190
      }
    ]
  },
  {
    id: 'REV-APX-B',
    productId: 'PRD-1001',
    revision: 'B',
    releaseDate: '2026-04-18',
    releasedBy: 'David Thorne (Principal EE)',
    ecoReference: 'ECO-2026-042',
    description: 'Current DVT Baseline: Swapped 4 discrete ESCs to unified 4-in-1 60A FOC controller, upgraded to 3D Livox LiDAR, converted airframe hardware to Titanium (-85g).',
    totalCost: 1348.60,
    totalWeightGrams: 2850,
    items: [
      {
        id: 'REV-B-01',
        partNumber: 'ASM-1000',
        name: 'AeroPulse-X4 Complete Unmanned System',
        revision: 'B',
        description: 'Complete assembled flight vehicle ready for factory acceptance calibration',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 1348.60,
        leadTimeWeeks: 8,
        lifecycle: 'DVT',
        sourcing: 'Custom Tooling',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'KITE-APX4-SYS-B',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: null,
        level: 0,
        weightGrams: 2850
      },
      {
        id: 'REV-B-02',
        partNumber: 'ASM-1100',
        name: 'Carbon Composite Airframe & Arm Structure',
        revision: 'B',
        description: 'Ultra-rigid 3K twill carbon fiber chassis with quick-fold arm locking mechanisms',
        category: 'Mechanical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 245.50,
        leadTimeWeeks: 4,
        lifecycle: 'DVT',
        sourcing: 'Multi Source',
        primarySupplier: 'Apex Precision CNC',
        primaryMpn: 'APX-FRM-002B',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-B-01',
        level: 1,
        weightGrams: 720
      },
      {
        id: 'REV-B-03',
        partNumber: 'FAS-1130',
        name: 'M3 x 8mm Grade 5 Titanium Button Head Torx Screws',
        revision: 'A',
        description: 'Ti-6Al-4V aerospace grade fasteners with blue threadlock pre-applied',
        category: 'Fasteners',
        quantity: 24,
        unitOfMeasure: 'ea',
        unitCost: 0.85,
        leadTimeWeeks: 2,
        lifecycle: 'Production',
        sourcing: 'Multi Source',
        primarySupplier: 'TitanFast Precision Hardware',
        primaryMpn: 'TI-M3-8-BTN-TRX',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-B-02',
        level: 2,
        weightGrams: 1.2
      },
      {
        id: 'REV-B-04',
        partNumber: 'ELE-1320',
        name: '4-in-1 60A FOC Motor Driver & Power Distribution PCBA',
        revision: 'B',
        description: 'CAN-bus telemetry FOC motor controller with regenerative active braking',
        category: 'PCBA',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 98.70,
        leadTimeWeeks: 4,
        lifecycle: 'DVT',
        sourcing: 'Multi Source',
        primarySupplier: 'Novatronics PCBA Solutions',
        primaryMpn: 'NVT-ESC-4IN1-60A',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-B-01',
        level: 2,
        weightGrams: 75
      },
      {
        id: 'REV-B-05',
        partNumber: 'OPT-1410',
        name: 'Solid-State Mid-Range LiDAR Sensor Core',
        revision: 'B',
        description: '200m range 905nm non-repetitive scanning beam sensor module',
        category: 'Optical',
        quantity: 1,
        unitOfMeasure: 'ea',
        unitCost: 295.00,
        leadTimeWeeks: 6,
        lifecycle: 'DVT',
        sourcing: 'Sole Source',
        primarySupplier: 'Sensirion & Optics Consortium',
        primaryMpn: 'LVX-MID-360-OEM',
        compliance: 'RoHS & REACH Compliant',
        amlList: [],
        parentId: 'REV-B-01',
        level: 2,
        weightGrams: 265
      }
    ]
  }
];

export const initialECOs: EngineeringChangeOrder[] = [
  {
    id: 'ECO-2026-042',
    ecoNumber: 'ECO-2026-042',
    title: 'Propulsion ESC Consolidation & Grade 5 Titanium Hardware Redline',
    productId: 'PRD-1001',
    productName: 'AeroPulse-X4 Industrial Inspection Drone',
    originator: 'David Thorne',
    originatorEmail: 'd.thorne@aeropulse.io',
    status: 'CCB Review',
    priority: 'Urgent',
    changeType: 'Cost Reduction',
    createdDate: '2026-09-14',
    targetImplementationDate: '2026-10-15',
    reasonForChange: 'Field testing during EVT revealed thermal bottlenecks with discrete 35A ESC drivers, while flight duration targets required an 80g weight reduction across airframe fasteners.',
    descriptionOfChange: '1. Replace 4x discrete ESCs (ELE-1320-A) with single 4-in-1 60A FOC controller board (ELE-1320-B), saving $25.30 in harness and component cost.\n2. Convert 24x M3 screws from 304 Stainless to Ti-6Al-4V Grade 5 Titanium, reducing overall dry weight by 48 grams.\n3. Update airframe hinge geometry to Rev B.',
    affectedItems: [
      {
        partId: 'BOM-1320',
        partNumber: 'ELE-1320',
        name: '4-in-1 60A FOC Motor Driver PCBA',
        fromRevision: 'A',
        toRevision: 'B',
        disposition: 'Rework Existing',
        quantityInStock: 45,
        scrapCost: 420.00,
        notes: 'Current Rev A boards to be flashed with diagnostic firmware and quarantined for bench testing.'
      },
      {
        partId: 'BOM-1130',
        partNumber: 'FAS-1130',
        name: 'Titanium Button Head Torx Screws M3x8',
        fromRevision: 'A',
        toRevision: 'B',
        disposition: 'Use As-Is',
        quantityInStock: 1200,
        scrapCost: 0,
        notes: 'Deplete existing stock on engineering prototypes; transition new builds at S/N #1040.'
      },
      {
        partId: 'BOM-1410',
        partNumber: 'OPT-1410',
        name: 'Solid-State Mid-Range LiDAR Sensor Core',
        fromRevision: 'A',
        toRevision: 'B',
        disposition: 'Phase-in at Serial #',
        quantityInStock: 12,
        scrapCost: 0,
        notes: 'Effective on flight vehicles starting at S/N #1080.'
      }
    ],
    totalScrapCost: 420.00,
    netUnitCostImpact: -72.20,
    signoffs: [
      {
        role: 'Lead Mechanical',
        assigneeName: 'Sarah Chen',
        assigneeTitle: 'Principal Mechanical Architect',
        signed: true,
        signedDate: '2026-09-16 14:22',
        comments: 'FEA stress analysis confirms Grade 5 titanium maintains 3.2x safety factor in 15G crash load.'
      },
      {
        role: 'Lead Electrical',
        assigneeName: 'David Thorne',
        assigneeTitle: 'Lead Electrical Engineer',
        signed: true,
        signedDate: '2026-09-17 09:15',
        comments: 'Thermal dissipation on 4-in-1 ESC bench test verified: runs 18°C cooler at 40A sustained hover.'
      },
      {
        role: 'Supply Chain',
        assigneeName: 'Elena Vance',
        assigneeTitle: 'Director of Strategic Sourcing',
        signed: false,
        comments: 'Pending Novatronics final quote confirmation for 500-unit lot.'
      },
      {
        role: 'Quality & Compliance',
        assigneeName: 'Marcus Rivera',
        assigneeTitle: 'Quality & Regulatory Manager',
        signed: false,
        comments: 'Awaiting updated RoHS certificate from TitanFast supplier.'
      }
    ]
  },
  {
    id: 'ECO-2026-039',
    ecoNumber: 'ECO-2026-039',
    title: 'STM32H7 Flight Controller Secondary Source Qualification',
    productId: 'PRD-1001',
    productName: 'AeroPulse-X4 Industrial Inspection Drone',
    originator: 'David Thorne',
    originatorEmail: 'd.thorne@aeropulse.io',
    status: 'Approved',
    priority: 'Standard',
    changeType: 'Obsolescence',
    createdDate: '2026-08-10',
    targetImplementationDate: '2026-09-30',
    reasonForChange: 'Global lead time for primary STM32H743 package extended to 36 weeks. Qualified alternate footprint on Rev B board layout.',
    descriptionOfChange: 'Added secondary footprint and firmware conditional compile flags for STM32H753 with hardware cryptographic acceleration.',
    affectedItems: [
      {
        partId: 'BOM-1220',
        partNumber: 'ELE-1220',
        name: 'Dual Core Cortex-M7 MCU 480MHz',
        fromRevision: 'A',
        toRevision: 'B',
        disposition: 'Use As-Is',
        quantityInStock: 250,
        scrapCost: 0,
        notes: 'Co-exist in AVL under multi-source policy.'
      }
    ],
    totalScrapCost: 0,
    netUnitCostImpact: 0,
    signoffs: [
      {
        role: 'Lead Mechanical',
        assigneeName: 'Sarah Chen',
        assigneeTitle: 'Principal Mechanical Architect',
        signed: true,
        signedDate: '2026-08-12 11:00',
        comments: 'No envelope changes.'
      },
      {
        role: 'Lead Electrical',
        assigneeName: 'David Thorne',
        assigneeTitle: 'Lead Electrical Engineer',
        signed: true,
        signedDate: '2026-08-12 11:30',
        comments: 'Pin-compatible drop-in verified on bench fixture.'
      },
      {
        role: 'Supply Chain',
        assigneeName: 'Elena Vance',
        assigneeTitle: 'Director of Strategic Sourcing',
        signed: true,
        signedDate: '2026-08-14 16:40',
        comments: 'Secured 1,000 pcs reel from Arrow with guaranteed 6-week window.'
      },
      {
        role: 'Quality & Compliance',
        assigneeName: 'Marcus Rivera',
        assigneeTitle: 'Quality & Regulatory Manager',
        signed: true,
        signedDate: '2026-08-15 08:30',
        comments: 'EMC pre-scan confirmed identical RF signature.'
      }
    ]
  },
  {
    id: 'ECO-2026-051',
    ecoNumber: 'ECO-2026-051',
    title: 'Fluorosilicone IP67 Gasket Shore Hardness Revision (Shore 50A to 40A)',
    productId: 'PRD-2002',
    productName: 'VeloSense-Edge IP67 Industrial IoT Gateway',
    originator: 'Sarah Chen',
    originatorEmail: 's.chen@velosense.com',
    status: 'Draft',
    priority: 'Standard',
    changeType: 'Reliability / Defect',
    createdDate: '2026-09-22',
    targetImplementationDate: '2026-11-01',
    reasonForChange: 'Sub-zero (-30°C) ingress test indicated compression set leak on corner radii when using Shore 50A material.',
    descriptionOfChange: 'Change compounding formulation to Shore 40A fluorosilicone and increase rib protrusion height by 0.25mm.',
    affectedItems: [
      {
        partId: 'BOM-2500',
        partNumber: 'MEC-2500',
        name: 'Molded Fluorosilicone IP67 Perimeter Seal Gasket',
        fromRevision: 'B',
        toRevision: 'C',
        disposition: 'Scrap Existing',
        quantityInStock: 300,
        scrapCost: 1020.00,
        notes: 'Scrap remaining 300 pcs of Rev B Shore 50A gaskets.'
      }
    ],
    totalScrapCost: 1020.00,
    netUnitCostImpact: 0.35,
    signoffs: [
      {
        role: 'Lead Mechanical',
        assigneeName: 'Sarah Chen',
        assigneeTitle: 'Principal Mechanical Architect',
        signed: true,
        signedDate: '2026-09-22 17:00',
        comments: 'Tooling core insert modification approved with TitanFast.'
      },
      {
        role: 'Lead Electrical',
        assigneeName: 'David Thorne',
        assigneeTitle: 'Lead Electrical Engineer',
        signed: false,
        comments: ''
      },
      {
        role: 'Supply Chain',
        assigneeName: 'Elena Vance',
        assigneeTitle: 'Director of Strategic Sourcing',
        signed: false,
        comments: ''
      },
      {
        role: 'Quality & Compliance',
        assigneeName: 'Marcus Rivera',
        assigneeTitle: 'Quality & Regulatory Manager',
        signed: false,
        comments: ''
      }
    ]
  }
];

export const initialRFQs: SupplierRFQ[] = [
  {
    id: 'RFQ-801',
    rfqNumber: 'RFQ-2026-801',
    supplierId: 'SUP-01',
    supplierName: 'Apex Precision CNC',
    supplierContact: 'engineering@apex-precision.de',
    partId: 'BOM-1420',
    partNumber: 'MEC-1420',
    partName: 'CNC 6061-T6 Aluminum Gimbal Yoke & Housing',
    status: 'Quoted',
    requestedQty: 500,
    targetPrice: 65.00,
    quotedPrice: 68.00,
    quotedLeadTimeWeeks: 3.5,
    quoteNotes: 'Price includes Type II black anodizing and laser-etched alignment indices. Tooling NRE waived at 500 pcs.',
    createdDate: '2026-09-10',
    quoteValidUntil: '2026-10-31',
    tierPricing: [
      { qty: 100, price: 82.00 },
      { qty: 500, price: 68.00 },
      { qty: 2500, price: 54.50 }
    ]
  },
  {
    id: 'RFQ-802',
    rfqNumber: 'RFQ-2026-802',
    supplierId: 'SUP-02',
    supplierName: 'Novatronics PCBA Solutions',
    supplierContact: 'npi-quotes@novatronics-mfg.com',
    partId: 'BOM-1320',
    partNumber: 'ELE-1320',
    partName: '4-in-1 60A FOC Motor Driver & Power Distribution PCBA',
    status: 'Quoted',
    requestedQty: 1000,
    targetPrice: 95.00,
    quotedPrice: 98.70,
    quotedLeadTimeWeeks: 4.0,
    quoteNotes: 'Includes ICT (In-Circuit Test) and conformal silicone coating for moisture protection.',
    createdDate: '2026-09-15',
    quoteValidUntil: '2026-11-15',
    tierPricing: [
      { qty: 250, price: 114.00 },
      { qty: 1000, price: 98.70 },
      { qty: 5000, price: 86.20 }
    ]
  },
  {
    id: 'RFQ-803',
    rfqNumber: 'RFQ-2026-803',
    supplierId: 'SUP-05',
    supplierName: 'TitanFast Precision Hardware',
    supplierContact: 'sales@titanfast-tw.com',
    partId: 'BOM-1130',
    partNumber: 'FAS-1130',
    partName: 'M3 x 8mm Grade 5 Titanium Button Head Torx Screws',
    status: 'Awarded',
    requestedQty: 10000,
    targetPrice: 0.80,
    quotedPrice: 0.85,
    quotedLeadTimeWeeks: 2.0,
    quoteNotes: 'Lot certification and material test report (MTR) included with every shipment.',
    createdDate: '2026-09-02',
    quoteValidUntil: '2026-12-01',
    tierPricing: [
      { qty: 2500, price: 1.10 },
      { qty: 10000, price: 0.85 },
      { qty: 50000, price: 0.68 }
    ]
  },
  {
    id: 'RFQ-804',
    rfqNumber: 'RFQ-2026-804',
    supplierId: 'SUP-01',
    supplierName: 'Apex Precision CNC',
    supplierContact: 'engineering@apex-precision.de',
    partId: 'BOM-2100',
    partNumber: 'MEC-2100',
    partName: 'CNC 6063 Aluminum Extruded Chassis Body',
    status: 'Open',
    requestedQty: 1000,
    targetPrice: 42.00,
    createdDate: '2026-09-25'
  }
];

// Helper to flatten a multi-level BOM tree into a flat array
export function flattenBOM(items: BOMItem[]): BOMItem[] {
  let result: BOMItem[] = [];
  for (const item of items) {
    result.push(item);
    if (item.children && item.children.length > 0) {
      result = result.concat(flattenBOM(item.children));
    }
  }
  return result;
}

// Find item in hierarchical tree
export function findBOMItem(items: BOMItem[], id: string): BOMItem | null {
  for (const item of items) {
    if (item.id === id) return item;
    if (item.children && item.children.length > 0) {
      const found = findBOMItem(item.children, id);
      if (found) return found;
    }
  }
  return null;
}
